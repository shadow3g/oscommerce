<?php

/*

  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce 

  Released under the GNU General Public License 

*/

define('TABLE_HEADING_CONFIGURATION_TITLE', 'Titolo');
define('TABLE_HEADING_CONFIGURATION_VALUE', 'Valore');
define('TABLE_HEADING_ACTION', 'Azione');

define('TEXT_INFO_EDIT_INTRO', 'Effettua i cambiamenti necessari');
define('TEXT_INFO_DATE_ADDED', 'Data di inserimento:');
define('TEXT_INFO_LAST_MODIFIED', 'Ultima modifica:');

?>
