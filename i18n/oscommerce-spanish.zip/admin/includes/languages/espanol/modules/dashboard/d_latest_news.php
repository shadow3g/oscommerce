<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_TITLE', 'Ultimas Noticias');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DESCRIPTION', 'Mostrar las últimas noticias de osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DATE', 'Fecha');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_FEED_ERROR', 'No se pudo conectar a la fuente de noticias osCommerce. El siguiente intento se llevará a cabo dentro de las 24 horas.');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWSLETTER', 'Inscríbase para recibir el boletín osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_FACEBOOK', 'Conviértete en un Fan de osCommerce en Facebook');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_TWITTER', 'Seguir a osCommerce en Twitter');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_RSS', 'Suscríbase a las noticias de osCommerce con RSS Feed');
// added for ver 2.3.4 bof 
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWS', 'Lea las últimas Noticias osCommerce '); 
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_GOOGLE_PLUS', 'Círculo osCommerce en Google+'); 
// added for ver 2.3.4 eof 
?>
