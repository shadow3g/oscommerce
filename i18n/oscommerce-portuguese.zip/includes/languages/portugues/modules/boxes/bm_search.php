<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SEARCH_TITLE', 'Pesquisa');
  define('MODULE_BOXES_SEARCH_DESCRIPTION', 'Mostrar campo de Pesquisa');
  define('MODULE_BOXES_SEARCH_BOX_TITLE', 'Pesquisa Rápida');
  define('MODULE_BOXES_SEARCH_BOX_TEXT', 'Utilize palavras chave para pesquisar Artigos.');
  define('MODULE_BOXES_SEARCH_BOX_ADVANCED_SEARCH', 'Pesquisa avançada');
?>