<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_TITLE', 'admin/backups/ Accès aux fichiers');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_HTTP_200', 'Les fichiers de sauvegarde en ' . DIR_WS_ADMIN . 'backups/ peuvent être consultés et téléchargés directement - s\'il vous plaît désactiver l\'accès du public à ce répertoire dans la configuration de votre serveur web.');
?>
