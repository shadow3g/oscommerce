<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPAL_STANDARD_TEXT_TITLE', 'PayPal Website Payments Standard');
  define('MODULE_PAYMENT_PAYPAL_STANDARD_TEXT_PUBLIC_TITLE', 'PayPal (incluindo Cart�es de Cr�dito e D�bito)');
  define('MODULE_PAYMENT_PAYPAL_STANDARD_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.paypal.com/mrb/pal=PS2X9Q773CKG4" target="_blank" style="text-decoration: underline; font-weight: bold;">Visite o site PayPal</a>&nbsp;<a href="javascript:toggleDivBlock(\'paypalStdInfo\');">(info)</a><span id="paypalStdInfo" style="display: none;"><br /><i>Ao efectuar o registo no PayPal oferece uma pequena ajuda financeira ao osCommerce por referenciar um cliente.</i></span>');
?>
