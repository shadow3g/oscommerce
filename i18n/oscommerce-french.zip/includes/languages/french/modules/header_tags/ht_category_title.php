<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_TITLE', 'Titre de la catégorie');
  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_DESCRIPTION', 'Ajoute le titre de la catégorie actuelle au titre de la page.');
?>
