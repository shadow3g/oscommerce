<?php
/*
  $Id: account_history.php,v 1.7 2003/05/19 20:17:50 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE_1', 'Im mio account');
define('NAVBAR_TITLE_2', 'I miei Acquisti');

define('HEADING_TITLE', 'I miei Acquisti');

define('TEXT_ORDER_NUMBER', 'Ordine numero:');
define('TEXT_ORDER_STATUS', 'Stato ordine:');
define('TEXT_ORDER_DATE', 'Data ordine:');
define('TEXT_ORDER_SHIPPED_TO', 'Spedito a:');
define('TEXT_ORDER_BILLED_TO', 'Fatturato a:');
define('TEXT_ORDER_PRODUCTS', 'Prodotti:');
define('TEXT_ORDER_COST', 'Costo ordine:');
define('TEXT_VIEW_ORDER', 'Mostra gli acquisti');

define('TEXT_NO_PURCHASES', 'Nessun acquisto effettuato.');
?>