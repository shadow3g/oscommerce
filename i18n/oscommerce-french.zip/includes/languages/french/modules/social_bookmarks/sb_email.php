<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_TITLE', 'Mail');
  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_DESCRIPTION', 'Permettre de faire connaitre les produits (partager) via Mail.');
  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_PUBLIC_TITLE', 'Partager par Mail');
?>
