<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Conta Pessoal');
define('NAVBAR_TITLE_2', 'Subscri��o de Newsletter');

define('HEADING_TITLE', 'Subscri��o de Newsletter');

define('MY_NEWSLETTERS_TITLE', 'Newsletter subscritas');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Newsletter Geral');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Anuncios de novidades da loja, artigos novos, promo��es e outros.');

define('SUCCESS_NEWSLETTER_UPDATED', 'As subscri��es de foram actualizadas com sucesso.');
?>
