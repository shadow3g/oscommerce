<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SEARCH_TITLE', 'Recherches');
  define('MODULE_BOXES_SEARCH_DESCRIPTION', 'Affiche un champs de recherche');
  define('MODULE_BOXES_SEARCH_BOX_TITLE', 'Recherche rapide');
  define('MODULE_BOXES_SEARCH_BOX_TEXT', 'Utilisez des mots-clés pour trouver le produit que vous recherchez.');
  define('MODULE_BOXES_SEARCH_BOX_ADVANCED_SEARCH', 'Recherche avancée');
?>
