<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Envio');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Custo de Envio da Encomenda');

  define('FREE_SHIPPING_TITLE', 'Envio Gratuito');
  define('FREE_SHIPPING_DESCRIPTION', 'Envio Gratuito para Encomendas de valor superior a %s');
?>