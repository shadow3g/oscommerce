<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_TITLE', 'autenticazione HTTP Admin');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_ERROR', 'autenticazione HTTP non è stato impostato per lo strumento Amministrazione osCommerce - si prega di impostare questa funzione nella configurazione del server Web per proteggere ulteriormente lo strumento di amministrazione da accessi non autorizzati.');
?>
