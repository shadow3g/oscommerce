<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_TITLE', 'authentification HTTP Admin');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_ERROR', 'authentification HTTP n\'a pas été mis en place pour l\'outil d\'administration osCommerce - s\'il vous plaît configurer cela dans la configuration de votre serveur Web pour protéger davantage l\'outil d\'administration des accès non autorisés.');
?>
