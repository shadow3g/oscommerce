<?php
/*
  $Id: ot_total.php,v 1.1 2002/04/03 23:09:49 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

  define('MODULE_ORDER_TOTAL_TOTAL_TITLE', 'Totale');
  define('MODULE_ORDER_TOTAL_TOTAL_DESCRIPTION', 'Totale Ordine');
?>