<?php
/*
  $Id: contact_us.php,v 1.7 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('HEADING_TITLE', 'Contattaci');
define('NAVBAR_TITLE', 'Contattaci');
define('TEXT_SUCCESS', 'La sua domanda è stata inviata al webmaster..');
define('EMAIL_SUBJECT', 'Domanda riguardante ' . STORE_NAME);

define('ENTRY_NAME', 'Nome e cognome:');
define('ENTRY_EMAIL', 'Indirizzo E-Mail:');
define('ENTRY_ENQUIRY', 'Domanda:');
define('ERROR_ACTION_RECORDER', 'Errore: il messaggio è già stato inviato. Riprova fra %s minuti.
');

?>
