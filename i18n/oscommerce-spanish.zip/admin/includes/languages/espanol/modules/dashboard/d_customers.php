<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_CUSTOMERS_TITLE', 'Clientes');
define('MODULE_ADMIN_DASHBOARD_CUSTOMERS_DESCRIPTION', 'Mostrar los nuevos Clientes');
define('MODULE_ADMIN_DASHBOARD_CUSTOMERS_DATE', 'Fecha');
?>
