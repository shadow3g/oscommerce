<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Controlo de Seguran�a');
define('HEADING_TITLE', 'Controlo de Seguran�a');

define('TEXT_INFORMATION', 'Foi detectado que o seu browser gerou diferentes Identifica��es de Sess�o SSL usadas na nossa loja on-line.<br /><br />Por motivos de seguran�a, � necess�rio que se autentique de novo com os seus Dados Pessoais para continuar.<br /><br />Alguns browsers, como o Konqueror 3.1, n�o t�m a capacidade de gerar Identifica��es de Sess�o Seguras SSL, como requerido. Se � o seu caso, recomendamos que utilize outro browser, como por exemplo <a href="http://www.microsoft.com/ie/" target="_blank">Microsoft Internet Explorer</a>, <a href="http://channels.netscape.com/ns/browsers/download_other.jsp" target="_blank">Netscape</a>, ou <a href="http://www.mozilla.org/releases/" target="_blank">Mozilla</a>.<br /><br />Esta � uma medida de seguran�a para proteger os seus dados pessoais.<br /><br />Se tiver alguma quest�o, por favor contacte-nos.');

define('BOX_INFORMATION_HEADING', 'Privacidade');
define('BOX_INFORMATION', 'Cada Identifica��o de Sess�o SSL � automaticamente validada em todas as p�ginas seguras do servidor.<br /><br />Esta valida��o assegura que a sua identifica��o n�o est� a ser utilizada por ninguem sem o seu conhecimento.');
?>
