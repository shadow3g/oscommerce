<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comet�rios');
define('HEADING_TITLE', ' %s Coment�rios');
define('SUB_TITLE_PRODUCT', 'Artigo:');
define('SUB_TITLE_FROM', 'Autor:');
define('SUB_TITLE_DATE', 'Data:');
define('SUB_TITLE_REVIEW', 'Coment�rio:');
define('SUB_TITLE_RATING', 'Classifica��o:');
define('TEXT_OF_5_STARS', '%s de 5 Estrelas!');
define('TEXT_CLICK_TO_ENLARGE', 'Clique para aumentar');
?>