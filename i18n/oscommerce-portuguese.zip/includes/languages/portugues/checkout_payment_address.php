<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Encomendar');
define('NAVBAR_TITLE_2', 'Alterar Endere�o de Factura��o');

define('HEADING_TITLE', 'Pagamento');

define('TABLE_HEADING_PAYMENT_ADDRESS', 'Endere�o de Factura��o');
define('TEXT_SELECTED_PAYMENT_DESTINATION', 'Este � o Endere�o de Factura��o seleccionado para o qual ir� ser enviada a Factura.');
define('TITLE_PAYMENT_ADDRESS', 'Endere�o de Factura��o:');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Endere�os');
define('TEXT_SELECT_OTHER_PAYMENT_DESTINATION', 'Por favor, seleccione o Endere�o de Factura��o se desejar que a Encomenda seja enviada para outro local.');
define('TITLE_PLEASE_SELECT', 'Seleccione');

define('TABLE_HEADING_NEW_PAYMENT_ADDRESS', 'Novo Endere�o de Factura��o');
define('TEXT_CREATE_NEW_PAYMENT_ADDRESS', 'Por favor, utilize o formul�rio para cria um novo Endere�o de Factura��o.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Continuar');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'para seleccionar o M�todo de Pagamento.');
?>
