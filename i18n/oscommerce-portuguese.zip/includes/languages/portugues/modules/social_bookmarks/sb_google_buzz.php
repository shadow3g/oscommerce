<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_BUZZ_TITLE', 'Google Buzz');
  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_BUZZ_DESCRIPTION', 'Partilhar no Google Buzz.');
  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_BUZZ_PUBLIC_TITLE', 'Partilhar no Google Buzz');
?>
