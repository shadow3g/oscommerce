<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Créer un comtpe');
define('NAVBAR_TITLE_2', 'Succès');
define('HEADING_TITLE', 'Votre compte a été créé !');
define('TEXT_ACCOUNT_CREATED', 'Félicitations ! Votre nouveau compte a été créé ! Vous pouvez maintenant profiter des privilèges de membre afin de tirer pleinement parti de notre site de commerce en ligne. Pour <small><strong>TOUTE</strong></small> question sur le fonctionnement de ce site, veuillez envoyer un courrier électronique au <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">gestionnaire du site</a>.<br /><br />Une confirmation de création de compte a été envoyée à l\'adresse électronique fournie. Si vous ne l\'avez pas reçu dans l\'heure, veuillez  <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">nous contacter</a>.');
?>
