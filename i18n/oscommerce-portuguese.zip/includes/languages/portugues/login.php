<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Entrar');
define('HEADING_TITLE', 'Bem vindo, autentique-se');

define('HEADING_NEW_CUSTOMER', 'Novo Cliente');
define('TEXT_NEW_CUSTOMER', 'Registo de Novo Cliente.');
define('TEXT_NEW_CUSTOMER_INTRODUCTION', 'Ao registar-se como Cliente da ' . STORE_NAME . ' poder� efectuar as suas compras de uma forma r�pida e c�moda, para al�m de consultar o estado e hist�rico de todas as Encomendas.');

define('HEADING_RETURNING_CUSTOMER', 'Cliente Registado');
define('TEXT_RETURNING_CUSTOMER', 'Autentique-se com os seus Dados.');

define('TEXT_PASSWORD_FORGOTTEN', 'Recordar Password?');

define('TEXT_LOGIN_ERROR', 'Erro: N�o existem registos para o E-Mail Address e/ou Password fornecidos.');
define('TEXT_VISITORS_CART', '<font color="#ff0000"><strong>Nota:</strong></font> O conte�do do &quot;Carrinho de Visitante&quot; ser� adicionado ao &quot;Carrinho de Cliente&quot; assim que entrar com os seus dados. <a href="javascript:session_win();">[Mais informa��o]</a>');
?>
