<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_TITLE', 'Merci');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_DESCRIPTION', 'Afficher merci bloquer sur la page de succès de la caisse.');

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SUCCESS', 'Votre commande a été traitée avec succès! Vos produits arriveront à destination dans les 2-5 jours ouvrables.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SEE_ORDERS', 'Vous pouvez consulter l\'état de votre commande à tout moment dans votre compte <a href="%s">Affichage des commandes</a> page.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_CONTACT_STORE_OWNER', 'S\'il vous plaît faire parvenir toute question que vous pourriez avoir à nous sur notre <a href="%s">Contactez-nous</a> page.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_THANKS_FOR_SHOPPING', 'Merci pour vos achats en ligne avec nous!');
?>
