<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_CONTACT_US_TITLE', 'Contáctenos');
  define('MODULE_ACTION_RECORDER_CONTACT_US_DESCRIPTION', 'Registro del uso de la característica Contáctanos.');
?>
