<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_BEST_SELLERS_TITLE', 'Meilleures ventes');
  define('MODULE_BOXES_BEST_SELLERS_DESCRIPTION', 'Affiche les meilleures ventes par catégories et globalement');
  define('MODULE_BOXES_BEST_SELLERS_BOX_TITLE', 'Meilleures ventes');
?>
