<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Produits en attente');

define('TABLE_HEADING_PRODUCTS', 'Produits');
define('TABLE_HEADING_DATE_EXPECTED', 'Date attendue');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_DATE_EXPECTED', 'Date attendue:');
?>