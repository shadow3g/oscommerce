<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_TITLE', 'Título del Producto');
  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_DESCRIPTION', 'Adicionar el título del producto actual para el título de la página');
?>
