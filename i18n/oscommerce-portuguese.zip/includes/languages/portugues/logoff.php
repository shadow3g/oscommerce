<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Sair');
define('NAVBAR_TITLE', 'Sair');
define('TEXT_MAIN', 'Saiu da sua Conta com sucesso. � seguro agora abandonar o computador.<br /><br />O seu Carrinho de Compras ficou guardado e ser� restaurado assim que entrar de novo.');
?>
