<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_TITLE', 'Ultime News');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DESCRIPTION', 'Mostra le ultime news su osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DATE', 'Data');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_FEED_ERROR', 'Non puoi connetterti ai feed di osCommerce News. Il prossimo tentativo avverr&agrave; tra 24 ore.');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWSLETTER', 'Iscriviti alla Newsletter di osCommerce ');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_FACEBOOK', 'Diventa un fan di osCommerce su Facebook');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_TWITTER', 'Segui osCommerce su Twitter');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_RSS', 'Sottoscrivi le osCommerce News RSS Feed');
// added for ver 2.3.4 bof
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWS', 'Leggi le ultime notizie osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_GOOGLE_PLUS', 'Circle osCommerce su Google+');
// added for ver 2.3.4 eof

?>
