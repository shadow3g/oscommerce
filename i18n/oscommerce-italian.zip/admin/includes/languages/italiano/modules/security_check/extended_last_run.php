<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_LAST_RUN_OLD', 'E i\'stato più di 30 giorni da quando i controlli di sicurezza sono stati estesi scorso eseguite. Si prega di eseguire nuovamente i controlli di sicurezza estesa in Strumenti -&gt; Controlli di sicurezza.');
?>
