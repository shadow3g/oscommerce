<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Contactez-nous');
define('NAVBAR_TITLE', 'Contactez-nous');
define('TEXT_SUCCESS', 'Votre requête a été envoyée au gestionnaire du site.');
define('EMAIL_SUBJECT', 'Demande en provenance de ' . STORE_NAME);

define('ENTRY_NAME', 'Nom et Prénom :');
define('ENTRY_EMAIL', 'Adresse email :');
define('ENTRY_ENQUIRY', 'Demande de renseignements :');

define('ERROR_ACTION_RECORDER', 'Erreur: Un formulaire de contact vient d\'être envoyé. Veuillez réessayer dans %s minutes.');
?>
