<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CANONICAL_TITLE', 'Liens de tête canoniques');
  define('MODULE_HEADER_TAGS_CANONICAL_DESCRIPTION', 'Ajouter tête liens canoniques à la catégorie de produits et pages');
?>
