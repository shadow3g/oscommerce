<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_REVIEWS_TITLE', 'Recensioni');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DESCRIPTION', 'Mostra le ultime recensioni');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEWER', 'Recensore');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DATE', 'Data');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_RATING', 'Rating');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEW_STATUS', 'Stato Recensioni');
?>
