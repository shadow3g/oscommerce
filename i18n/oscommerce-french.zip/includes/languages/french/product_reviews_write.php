<?php
/*
  $Id: product_reviews_write.php $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Avis des clients');

define('SUB_TITLE_FROM', 'De :');
define('SUB_TITLE_REVIEW', 'Votre avis :');
define('SUB_TITLE_RATING', 'Classement :');
define('TEXT_NO_HTML', '<small><font color="#ff0000"><strong>REMARQUE:</strong></font></small>&nbsp;Le code HTML n\'est pas pris en compte !');
define('TEXT_BAD', '<small><font color="#ff0000"><strong>MAUVAIS</strong></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><strong>BON</strong></font></small>');

define('TEXT_CLICK_TO_ENLARGE', 'Cliquer pour agrandir');

define('TEXT_REVIEW_RECEIVED', 'Merci d\'avoir donné votre avis. Il a été soumis à l\'administrateur du site et sera publié prochainement.');

?>
