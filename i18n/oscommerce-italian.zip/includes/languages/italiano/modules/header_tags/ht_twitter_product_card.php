<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TITLE', 'Twitter Scheda Prodotto');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_DESCRIPTION', 'Aggiungi Twitter tags scheda prodotto alle tue pagine di informazioni sul prodotto');

  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_PRE_ORDER', 'Ordine prestabilito');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_IN_STOCK', 'In magazzino');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_OUT_OF_STOCK', 'Esaurito');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_BUY_NOW', 'ACQUISTA ORA');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_CONTACT_US', 'CONTATTACI');
?>
