<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comentarios');

define('SUB_TITLE_FROM', 'De:');
define('SUB_TITLE_REVIEW', 'Su Comentario:');
define('SUB_TITLE_RATING', 'Valoración:');

define('TEXT_NO_HTML', '<small><font color="#ff0000"><strong>NOTA:</strong></font></small>&nbsp;No se traduce el código HTML!');
define('TEXT_BAD', '<small><font color="#ff0000"><strong>MALO</strong>></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><strong>BUENO</strong></font></small>');

define('TEXT_REVIEW_RECEIVED', 'Gracias por su comentario. Se ha enviado al Administrador de la tienda para su aprobacióny debera aparecer en breve.');

define('TEXT_CLICK_TO_ENLARGE', 'Haga click para Ampliar');
?>
