<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Prodotti in arrivo');

define('TABLE_HEADING_PRODUCTS', 'Prodotti');
define('TABLE_HEADING_DATE_EXPECTED', 'Data di arrivo');
define('TABLE_HEADING_ACTION', 'Azione');

define('TEXT_INFO_DATE_EXPECTED', 'Data di arrivo:');
?>
