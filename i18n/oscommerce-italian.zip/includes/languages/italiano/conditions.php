<?php
/*
  $Id: conditions.php,v 1.4 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE', 'Condizioni per l\'uso');
define('HEADING_TITLE', 'Condizioni per l\'uso');

define('TEXT_INFORMATION', 'Le presenti condizioni generali di vendita e di consegna si applicano a tutti i contratti di acquisto che sono inclusi con il Web Shop Shop, Bertil Palmqvist. Ordinando si accettano questi termini e condizioni. <br /> <br />
Vedere il testo integrale in lingua svedese o inglese, cliccando sulla bandiera del paese nella colonna di destra. È quindi possibile tornare alla lingua cliccando sulla bandiera del paese.');
?>