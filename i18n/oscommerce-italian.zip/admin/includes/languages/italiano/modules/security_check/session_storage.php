<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_SESSION_DIRECTORY_NON_EXISTENT', 'Le sessioni directory non esistono: ' . tep_session_save_path() . '. La sessione non funzioner&agrave; finch&egrave; questa directory non sar&agrave; creata.');
define('WARNING_SESSION_DIRECTORY_NOT_WRITEABLE', 'Non sono abilitato a scrivere in questa sessions directory: ' . tep_session_save_path() . '. La sessione non funzioner&agrave; finch&egrave; non verranno settati i giusti permessi');
?>
