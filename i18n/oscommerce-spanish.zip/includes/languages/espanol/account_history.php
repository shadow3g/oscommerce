<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Histórico');

define('HEADING_TITLE', 'Historial de Pedidos');

define('TEXT_ORDER_NUMBER', 'Número de Pedido:');
define('TEXT_ORDER_STATUS', 'Estado del Pedido:');
define('TEXT_ORDER_DATE', 'Fecha del Pedido:');
define('TEXT_ORDER_SHIPPED_TO', 'Enviado a:');
define('TEXT_ORDER_BILLED_TO', 'Facturar a:');
define('TEXT_ORDER_PRODUCTS', 'Productos:');
define('TEXT_ORDER_COST', 'Importe Total:');
define('TEXT_VIEW_ORDER', 'Ver Pedido');

define('TEXT_NO_PURCHASES', 'No ha realizado ningún pedido aún.');
?>
