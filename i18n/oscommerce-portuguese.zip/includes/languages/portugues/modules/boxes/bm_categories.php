<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CATEGORIES_TITLE', 'Categorias');
  define('MODULE_BOXES_CATEGORIES_DESCRIPTION', 'Mostrar navegação das Categorias');
  define('MODULE_BOXES_CATEGORIES_BOX_TITLE', 'Categorias');
?>