<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Expédition');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Coût d\'Expédition');

  define('FREE_SHIPPING_TITLE', 'Expédition gratuite');
  define('FREE_SHIPPING_DESCRIPTION', 'Expédition gratuite pour les commandes supérieures à %s');
?>