<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CARD_ACCEPTANCE_TITLE', 'Accettazione Carta');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DESCRIPTION', 'Mostra i loghi di accettazione delle carte di pagamento');

  define('MODULE_BOXES_CARD_ACCEPTANCE_SHOWN_CARDS', 'Carte mostrate');
  define('MODULE_BOXES_CARD_ACCEPTANCE_NEW_CARDS', 'Nuovo Carte');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DRAG_HERE', 'Trascina qui');

  define('MODULE_BOXES_CARD_ACCEPTANCE_BOX_TITLE', 'Accettiamo');
?>
