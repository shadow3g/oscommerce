<?php
/*
  $Id: checkout_payment_address.php,v 1.2 2003/05/19 20:17:50 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE_1', 'Acquista');
define('NAVBAR_TITLE_2', 'Cambia l\'indirizzo per la fattura');

define('HEADING_TITLE', 'Informazioni di pagamento');

define('TABLE_HEADING_PAYMENT_ADDRESS', 'Indirizzo per la fattura');
define('TEXT_SELECTED_PAYMENT_DESTINATION', 'Questo è l\' indirizzo di fatturazione dove la fattura verrà spedita.');
define('TITLE_PAYMENT_ADDRESS', 'Indirizzo per la fattura:');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Entra nella rubrica');
define('TEXT_SELECT_OTHER_PAYMENT_DESTINATION', 'Seleziona l\' indirizzo di fatturazione che preferisci se la fattura per questo ordine deve essere spedita altrove.');
define('TITLE_PLEASE_SELECT', 'Seleziona');

define('TABLE_HEADING_NEW_PAYMENT_ADDRESS', 'Nuovo indirizzo per la fattura');
define('TEXT_CREATE_NEW_PAYMENT_ADDRESS', 'Utilizza questo modulo per creare un nuovo indirizzo di fatturazione.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Continua la procedura di acquisto');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'per selezionare il metodo di pagamento che preferisci.');
?>