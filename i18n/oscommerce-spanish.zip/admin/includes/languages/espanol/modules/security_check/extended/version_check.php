<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_TITLE', 'Comprobación de la versión');
define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_ERROR', 'Una nueva comprobación de versión se realizó hace más de 30 días. Por favor, realice la comprobación para ver si hay una nueva versión disponible.');
?>
