<?php
/*
  $Id: product_reviews_info.php,v 1.6 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE', 'Recensioni');
define('HEADING_TITLE', ' %s Recensioni');
define('SUB_TITLE_PRODUCT', 'Prodotto:');
define('SUB_TITLE_FROM', 'Da:');
define('SUB_TITLE_DATE', 'Data:');
define('SUB_TITLE_REVIEW', 'Recensione:');
define('SUB_TITLE_RATING', 'Votazione:');
define('TEXT_OF_5_STARS', '%s su 5 stele!');
define('TEXT_CLICK_TO_ENLARGE', 'Clicca per ingrandire');
?>