<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_PINTEREST_TITLE', 'Pinterest');
  define('MODULE_SOCIAL_BOOKMARKS_PINTEREST_DESCRIPTION', 'Partager sur Pinterest');
  define('MODULE_SOCIAL_BOOKMARKS_PINTEREST_PUBLIC_TITLE', 'Pin It');
?>
