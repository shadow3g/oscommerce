<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TITLE', 'Twitter Ficha de Producto');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_DESCRIPTION', 'Agregar Twitter etiquetas de tarjeta Producto a las páginas de información del producto.');

  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_PRE_ORDER', 'Pedido anticipado');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_IN_STOCK', 'En Stock');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_OUT_OF_STOCK', 'Fuera de Stock');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_BUY_NOW', 'COMPRAR AHORA');
  define('MODULE_HEADER_TAGS_TWITTER_PRODUCT_CARD_TEXT_CONTACT_US', 'CONTACTENOS');
?>
