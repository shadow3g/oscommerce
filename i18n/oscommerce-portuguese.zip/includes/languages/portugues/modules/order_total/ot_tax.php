<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_TAX_TITLE', 'IVA');
  define('MODULE_ORDER_TOTAL_TAX_DESCRIPTION', 'IVA da Encomenda');
?>