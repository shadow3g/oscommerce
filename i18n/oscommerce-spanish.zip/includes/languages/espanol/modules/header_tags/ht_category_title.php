<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_TITLE', 'Título de la categoría');
  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_DESCRIPTION', 'Adicionar el título de la categoría actual para el título de la página');
?>
