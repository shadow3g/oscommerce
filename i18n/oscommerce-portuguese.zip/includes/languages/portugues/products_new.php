<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Novidades');
define('HEADING_TITLE', 'Novidades');

define('TEXT_DATE_ADDED', 'Adicionado:');
define('TEXT_MANUFACTURER', 'Marca:');
define('TEXT_PRICE', 'Pre�o:');
?>