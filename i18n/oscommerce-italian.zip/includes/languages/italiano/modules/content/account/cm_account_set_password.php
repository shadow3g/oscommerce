<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_TITLE', 'Imposta password account');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_DESCRIPTION', 'Se è stata impostata alcuna password di account locale Sostituire Cambiare pagina Password con la pagina Imposta password');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_LINK_TITLE', 'Imposta password dell\'account. ');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_1', 'Il mio account');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_2', 'Imposta password');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_HEADING_TITLE', 'Imposta password');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_TITLE', 'Imposta password');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SUCCESS_PASSWORD_SET', 'La tua password è stata salvata con successo.');
?>
