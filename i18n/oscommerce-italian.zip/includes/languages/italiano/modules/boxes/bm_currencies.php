<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CURRENCIES_TITLE', 'Valute');
  define('MODULE_BOXES_CURRENCIES_DESCRIPTION', 'Mostra valute disponibili');
  define('MODULE_BOXES_CURRENCIES_BOX_TITLE', 'Valute');
?>
