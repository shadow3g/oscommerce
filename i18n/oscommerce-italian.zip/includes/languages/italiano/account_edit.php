<?php
/*
  $Id: account_edit.php,v 1.8 2003/05/19 20:17:50 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE_1', 'Il mio account');
define('NAVBAR_TITLE_2', 'Modifica account');

define('HEADING_TITLE', 'Informazioni sul mio account');

define('MY_ACCOUNT_TITLE', 'Il mio account');

define('SUCCESS_ACCOUNT_UPDATED', 'Il tuo account è stato modificato con successo.');
?>