<?php
/*
  $Id: table.php,v 1.5 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('MODULE_SHIPPING_TABLE_TEXT_TITLE', 'Tariffa prezzo per peso o valore');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION', 'Tariffa variabile in base al prezzo o al peso');
define('MODULE_SHIPPING_TABLE_TEXT_WAY', 'Corriere Espresso Nazionale');
define('MODULE_SHIPPING_TABLE_TEXT_WEIGHT', 'Peso');
define('MODULE_SHIPPING_TABLE_TEXT_AMOUNT', 'Importo');
?>
