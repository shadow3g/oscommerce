<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Conta Pessoal');
define('NAVBAR_TITLE_2', 'Editar Detalhes');

define('HEADING_TITLE', 'Informa��es Pessoais');

define('MY_ACCOUNT_TITLE', 'Conta Pessoal');

define('SUCCESS_ACCOUNT_UPDATED', 'A Conta Pessoal foi actualizada com sucesso.');
?>
