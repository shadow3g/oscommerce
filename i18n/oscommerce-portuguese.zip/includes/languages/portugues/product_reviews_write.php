<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Coment�rios');

define('SUB_TITLE_FROM', 'Autor:');
define('SUB_TITLE_REVIEW', 'Coment�rio:');
define('SUB_TITLE_RATING', 'Classifica��o:');

define('TEXT_NO_HTML', '<small><font color="#ff0000"><strong>NOTA:</strong></font></small>&nbsp;HTML n�o � suportado!');
define('TEXT_BAD', '<small><font color="#ff0000"><strong>MAU</strong></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><strong>BOM</strong></font></small>');

define('TEXT_REVIEW_RECEIVED', 'Obrigado! O seu coment�rio foi submetido a aprova��o e dever� ser publicado brevemente.');

define('TEXT_CLICK_TO_ENLARGE', 'Clique para aumentar');
?>
