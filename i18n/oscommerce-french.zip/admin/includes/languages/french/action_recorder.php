<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Enregistreur de sécurité');

define('TABLE_HEADING_MODULE', 'Module');
define('TABLE_HEADING_CUSTOMER', 'Client');
define('TABLE_HEADING_DATE_ADDED', 'Date');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_FILTER_SEARCH', 'Rechercher:');
define('TEXT_ALL_MODULES', '-- Tous les modules --');
define('TEXT_GUEST', 'Invité');

define('TEXT_INFO_IDENTIFIER', 'Identifiant:');
define('TEXT_INFO_DATE_ADDED', 'Date d\'ajout:');

define('SUCCESS_EXPIRED_ENTRIES', 'Réussite: %s entrées périmées ont été éffacées.');
?>
