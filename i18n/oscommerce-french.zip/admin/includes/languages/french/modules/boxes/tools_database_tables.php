<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULES_ADMIN_MENU_TOOLS_DATABASE_TABLES', 'Tables de base de données');
?>
