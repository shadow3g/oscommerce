<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURERS_TITLE', 'Marcas');
  define('MODULE_BOXES_MANUFACTURERS_DESCRIPTION', 'Mostrar lista de Marcas');
  define('MODULE_BOXES_MANUFACTURERS_BOX_TITLE', 'Marcas');
?>
