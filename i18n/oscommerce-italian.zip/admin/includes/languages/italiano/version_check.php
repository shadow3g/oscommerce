<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Controlla Versione');

define('TABLE_HEADING_VERSION', 'Versione');
define('TABLE_HEADING_RELEASED', 'Data rilascio');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_RELEASE_LINK', 'Vedi se ci sono aggiornamenti');

define('TITLE_INSTALLED_VERSION', 'Versione Installata:');

define('VERSION_RUNNING_LATEST', 'E\' presente l\'ultima versione di osCommerce Online Merchant.');
define('VERSION_UPGRADES_AVAILABLE', 'Una nuova versione di OsCommerce &egrave; disponibile per il download! (osCommerce Online Merchant v%s)');

define('ERROR_COULD_NOT_CONNECT', 'Non posso connettermi al sito ufficiale di osCommerce website per controllare se ci sono aggiornamenti.');
?>
