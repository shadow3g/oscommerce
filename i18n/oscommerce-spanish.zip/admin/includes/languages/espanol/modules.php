<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_MODULES', 'Módulos');
define('TABLE_HEADING_SORT_ORDER', 'Orden');
define('TABLE_HEADING_ACTION', 'Acción');

define('TEXT_INFO_VERSION', 'Versión:');
define('TEXT_INFO_ONLINE_STATUS', 'Estado de conexión');
define('TEXT_INFO_API_VERSION', 'Versión de la API:');

define('TEXT_MODULE_DIRECTORY', 'Directorio de Módulos:');
?>
