<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Fermer la session');
define('NAVBAR_TITLE', 'Fermer la session');
define('TEXT_MAIN', 'Vous avez fermé votre session. Vous pouvez laisser votre ordinateur allumé sans risque d\'utilisation de votre compte.<br /><br />Votre panier en cours a été sauvegardé, ses produits vous seront proposés lors de votre prochaine ouverture de session.');
?>
