<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_ORDER_HISTORY_TITLE', 'Hist��rico de Encomendas');
  define('MODULE_BOXES_ORDER_HISTORY_DESCRIPTION', 'Mostrar hist��rico de  Encomendas de clientes');
  define('MODULE_BOXES_ORDER_HISTORY_BOX_TITLE', 'Hist��rico de Encomendas');
?>