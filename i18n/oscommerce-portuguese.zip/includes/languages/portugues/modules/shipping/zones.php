<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ZONES_TEXT_TITLE', 'Taxa por Regi�o');
define('MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION', 'Taxa por Regi�o');
define('MODULE_SHIPPING_ZONES_TEXT_WAY', 'Entregar em');
define('MODULE_SHIPPING_ZONES_TEXT_UNITS', 'kg(s)');
define('MODULE_SHIPPING_ZONES_INVALID_ZONE', 'N�o � poss�vel enviar para esta Regi�o');
define('MODULE_SHIPPING_ZONES_UNDEFINED_RATE', 'N�o � poss�vel calcular a taxa de envio neste momento');
?>
