<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('ERROR_NO_DEFAULT_LANGUAGE_DEFINED', 'Errore: Non risulta impostata nessuna lingua come predefinita. Impostane una su: Pannello Amministrazione->Localizazione->Lingue');
?>
