<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Conta Pessoal');
define('HEADING_TITLE', 'Informa��o da Conta Pessoal');

define('OVERVIEW_TITLE', 'Geral');
define('OVERVIEW_SHOW_ALL_ORDERS', '(mostrar todas as encomendas)');
define('OVERVIEW_PREVIOUS_ORDERS', 'Encomendas Anteriores');

define('MY_ACCOUNT_TITLE', 'Conta Pessoal');
define('MY_ACCOUNT_INFORMATION', 'Visualisar ou modificar Dados Pessoais.');
define('MY_ACCOUNT_ADDRESS_BOOK', 'Visualisar ou modificar Endere�os.');
define('MY_ACCOUNT_PASSWORD', 'Modificar Password.');

define('MY_ORDERS_TITLE', 'Encomendas');
define('MY_ORDERS_VIEW', 'Visualisar todas as Encomendas.');

define('EMAIL_NOTIFICATIONS_TITLE', 'Newsletters por E-Mail');
define('EMAIL_NOTIFICATIONS_NEWSLETTERS', 'Subscrever ou Anular Subscri��o de Newsletters.');
define('EMAIL_NOTIFICATIONS_PRODUCTS', 'Visualisar ou modificar lista de Artigos a notificar.');
?>