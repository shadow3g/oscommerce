<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Encomendar');
define('NAVBAR_TITLE_2', 'Sucesso');

define('HEADING_TITLE', 'A Encomenda foi processada!');

define('TEXT_SUCCESS', 'A Encomenda foi processada com sucesso! Receber� um E-Mail com mais informa��es acerca da entrega.');
define('TEXT_NOTIFY_PRODUCTS', 'Notificar actualiza��es acerca dos Artigos seleccionados:');
define('TEXT_SEE_ORDERS', 'Para visualisar o Hist�rico de Encomendas clique <a href="' . tep_href_link(FILENAME_ACCOUNT, '', 'SSL') . '">\'Conta Pessoal\'</a> e em <a href="' . tep_href_link(FILENAME_ACCOUNT_HISTORY, '', 'SSL') . '">\'Hist�rico\'</a>.');
define('TEXT_CONTACT_STORE_OWNER', 'Para qualquer quest�o <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">contacte-nos</a>.');
define('TEXT_THANKS_FOR_SHOPPING', 'Obrigado pela sua Encomenda!');

define('TABLE_HEADING_COMMENTS', 'Adicione um comet�rio');

define('TABLE_HEADING_DOWNLOAD_DATE', 'Data de Validade: ');
define('TABLE_HEADING_DOWNLOAD_COUNT', ' downloads restantes');
define('HEADING_DOWNLOAD', 'Efectue o Download aqui:');
define('FOOTER_DOWNLOAD', 'Pode efectuar o Download mais tarde aqui: \'%s\'');
?>