<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_LAST_RUN_OLD', 'Han pasado más de 30 días desde que los controles de seguridad ampliada se realizaron el pasado. Por favor, vuelva a ejecutar los controles de seguridad ampliada en Herramientas -&gt; Controles de Seguridad.');
?>
