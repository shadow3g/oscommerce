<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Libreta de direcciones');

define('HEADING_TITLE', 'Mi Libreta de direcciones personal');

define('PRIMARY_ADDRESS_TITLE', 'Dirección Principal');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Esta dirección se utiliza como los datos de envío pre-seleccionado y la dirección de facturación para los pedidos realizados en esta tienda.<br /><br />Esta dirección también se utiliza como la base para calcular los impuestos y servicio.');

define('ADDRESS_BOOK_TITLE', 'Entradas de la Libreta de direcciones');

define('PRIMARY_ADDRESS', '(Dirección principal)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTA:</b></font> Se permiten un máximo de %s direcciones.');
?>
