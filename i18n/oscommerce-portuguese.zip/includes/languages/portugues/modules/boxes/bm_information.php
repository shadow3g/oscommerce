<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', ' Informações');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Mostrar Informações');
  define('MODULE_BOXES_INFORMATION_BOX_TITLE', ' Informações');
  define('MODULE_BOXES_INFORMATION_BOX_PRIVACY', 'Privacidade');
  define('MODULE_BOXES_INFORMATION_BOX_CONDITIONS', 'Termos de Utilização');
  define('MODULE_BOXES_INFORMATION_BOX_SHIPPING', 'Envios');
  define('MODULE_BOXES_INFORMATION_BOX_CONTACT', 'Contacte-nos');
?>