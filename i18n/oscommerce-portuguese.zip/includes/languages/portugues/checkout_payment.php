<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Encomendar');
define('NAVBAR_TITLE_2', 'M�todo de Pagamento');

define('HEADING_TITLE', 'Pagamento');

define('TABLE_HEADING_BILLING_ADDRESS', 'Endere�o de Factura��o');
define('TEXT_SELECTED_BILLING_DESTINATION', 'Por favor, seleccione o Endere�o para o qual ser� enviada a Factura.');
define('TITLE_BILLING_ADDRESS', 'Endere�o de Factura��o:');

define('TABLE_HEADING_PAYMENT_METHOD', 'M�todo de Pagamento');
define('TEXT_SELECT_PAYMENT_METHOD', 'Por favor, seleccione o M�todo de Pagamento para esta Encomenda.');
define('TITLE_PLEASE_SELECT', 'Seleccione');
define('TEXT_ENTER_PAYMENT_INFORMATION', 'Este � o �nico M�todo de Pagamento disponivel para esta Encomenda.');

define('TABLE_HEADING_COMMENTS', 'Adicionar Coment�rios');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Continuar');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'para confirma��o da Encomenda.');
?>
