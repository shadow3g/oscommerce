<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_TITLE', 'Gracias');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_DESCRIPTION', 'Mostrar gracias a bloquear en la página de éxito checkout.');

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SUCCESS', 'Su pedido ha sido procesado con éxito! Sus productos llegarán a su destino dentro de 2-5 días laborables.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SEE_ORDERS', 'Puede ver el estado de su pedido en cualquier momento en su cuenta <a href="%s">Ver Ordenes</a> página.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_CONTACT_STORE_OWNER', 'Por favor enviar cualquier pregunta que pueda tener para nosotros en nuestro <a href="%s">contáctenos</a> página.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_THANKS_FOR_SHOPPING', 'Gracias por comprar con nosotros!');
?>
