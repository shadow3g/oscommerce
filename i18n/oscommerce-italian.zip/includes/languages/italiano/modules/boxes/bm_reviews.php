<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Recensioni');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Mostra recensioni prodotto');
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Recensioni');
  define('MODULE_BOXES_REVIEWS_BOX_WRITE_REVIEW', 'Scrivi una recensione su questo prodotto!');
  define('MODULE_BOXES_REVIEWS_BOX_NO_REVIEWS', 'Al momento non ci sono recensioni su questo prodotto');
  define('MODULE_BOXES_REVIEWS_BOX_TEXT_OF_5_STARS', '%s su 5 Stelle!');
?>
