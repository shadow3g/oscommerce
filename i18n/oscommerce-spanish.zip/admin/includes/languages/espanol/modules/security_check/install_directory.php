<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_INSTALL_DIRECTORY_EXISTS', 'El directorio de instalación existe en: ' . DIR_FS_CATALOG . 'install. Por favor, elimine este directorio por razones de seguridad.');
?>
