<?php
/*
  $Id: create_account_success.php,v 1.9 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE_1', 'Crea un  Account');
define('NAVBAR_TITLE_2', 'Successo');
define('HEADING_TITLE', 'Il tuo account è stato creato!');
define('TEXT_ACCOUNT_CREATED', 'Congratulazioni! Il tuo nuovo account è stato creato con successo! Può ora usufruire dei privilegi da membro. Se tu hai <small><b>qualsiasi</b></small> dubbio sul funzionamento di questo negozio on-line, manda una e-mail all\' <a href="' . tep_href_link(FILENAME_CONTACT_US) . '"><b>amministratore</b></a>.<br><br>Una conferma è stata inviata all\'indirizzo specificato. Se non l\'hai ricevuta entro poche ore, <a href="' . tep_href_link(FILENAME_CONTACT_US) . '"><b>contattaci</b></a>.');
?>