<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_TITLE', 'T�tulo da Categoria');
  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_DESCRIPTION', 'Adicionar o t�tulo da Categoria actual ao t�tulo da p�gina');
?>
