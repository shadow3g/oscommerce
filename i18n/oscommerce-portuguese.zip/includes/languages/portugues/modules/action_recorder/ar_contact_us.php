<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_CONTACT_US_TITLE', 'Contactos');
  define('MODULE_ACTION_RECORDER_CONTACT_US_DESCRIPTION', 'Hist�rico de Utiliza��o dos Contactos.');
?>
