<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_TITLE', 'Contrôle de version');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DESCRIPTION', 'Affiche le résultat du contrôle de version');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DATE', 'Dernière vérification');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_CHECK_NOW', 'Vérifier maintenant');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_NEVER', 'Jamais');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_UPDATE_AVAILABLE', 'Une mise à jour pour osCommerce Online Merchant est disponible!');
?>
