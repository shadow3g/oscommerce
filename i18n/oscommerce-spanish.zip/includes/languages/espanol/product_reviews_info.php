<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comentarios');
define('HEADING_TITLE', ' %s Comentarios');
define('SUB_TITLE_PRODUCT', 'Producto:');
define('SUB_TITLE_FROM', 'De:');
define('SUB_TITLE_DATE', 'Fecha:');
define('SUB_TITLE_REVIEW', 'Comentario:');
define('SUB_TITLE_RATING', 'Valoración:');
define('TEXT_OF_5_STARS', '%s de 5 Estrellas!');
define('TEXT_CLICK_TO_ENLARGE', 'Haga click para ampliar');
?>
