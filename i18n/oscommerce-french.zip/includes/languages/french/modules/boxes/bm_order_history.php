<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_ORDER_HISTORY_TITLE', 'Historique des commandes');
  define('MODULE_BOXES_ORDER_HISTORY_DESCRIPTION', 'Affiche les produits déjà commandés lorsque le client est identifié.');
  define('MODULE_BOXES_ORDER_HISTORY_BOX_TITLE', 'Historique des commandes');
?>
