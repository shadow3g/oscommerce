<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('EMAIL_TEXT_SUBJECT', 'Encomenda');
define('EMAIL_TEXT_ORDER_NUMBER', 'Encomenda N.�:');
define('EMAIL_TEXT_INVOICE_URL', 'Detalhes:');
define('EMAIL_TEXT_DATE_ORDERED', 'Data:');
define('EMAIL_TEXT_PRODUCTS', 'Artigos');
define('EMAIL_TEXT_SUBTOTAL', 'Sub-Total:');
define('EMAIL_TEXT_TAX', 'IVA:        ');
define('EMAIL_TEXT_SHIPPING', 'Envio: ');
define('EMAIL_TEXT_TOTAL', 'Total:    ');
define('EMAIL_TEXT_DELIVERY_ADDRESS', 'Endere�o de Entrega');
define('EMAIL_TEXT_BILLING_ADDRESS', 'Endere�o de Factura��o');
define('EMAIL_TEXT_PAYMENT_METHOD', 'M�todo de Pagamento');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('TEXT_EMAIL_VIA', 'via');
?>