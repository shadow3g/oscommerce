<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Conta Pessoal');
define('NAVBAR_TITLE_2', 'Livro de Endere�os');

define('HEADING_TITLE', 'Livro de Endere�os');

define('PRIMARY_ADDRESS_TITLE', 'Endere�o Principal');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Este Endere�o ser� utilizado como pr�-defini��o para Factura��o e Envio das Encomendas.<br /><br />Este endere�o � tambem utilizado para c�lculo do IVA ou outras Taxas.');

define('ADDRESS_BOOK_TITLE', 'Endere�os');

define('PRIMARY_ADDRESS', '(endere�o principal)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><strong>NOTA:</strong></font> Apenas s�o permitidos %s endere�os.');
?>
