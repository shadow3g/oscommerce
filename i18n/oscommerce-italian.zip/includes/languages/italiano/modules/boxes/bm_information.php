<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'Informazioni');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Mostra link pagina informazione');
  define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Informazioni');
  define('MODULE_BOXES_INFORMATION_BOX_PRIVACY', 'Avviso privacy');
  define('MODULE_BOXES_INFORMATION_BOX_CONDITIONS', 'Condizioni d\'uso');
  define('MODULE_BOXES_INFORMATION_BOX_SHIPPING', 'Consegna &amp; Restituzione');
  define('MODULE_BOXES_INFORMATION_BOX_CONTACT', 'Contattaci');
?>
