<?php
/*
  $Id: checkout_shipping_address.php,v 1.2 2003/05/19 20:17:50 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE_1', 'Acquista');
define('NAVBAR_TITLE_2', 'Cambia l\' indirizzo per la spedizione');

define('HEADING_TITLE', 'Informazioni spedizione');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Indirizzo per la spedizione');
define('TEXT_SELECTED_SHIPPING_DESTINATION', 'Questo è l\'attuale indirizzo di spedizione dove i prodotti di questo ordine verranno spediti');
define('TITLE_SHIPPING_ADDRESS', 'Indirizzo per la spedizione:');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Entra nella rubrica');
define('TEXT_SELECT_OTHER_SHIPPING_DESTINATION', 'Seleziona l\' indirizzo di spedizione preferito, se i prodotti di questo ordine devono essere spediti altrove.');
define('TITLE_PLEASE_SELECT', 'Seleziona');

define('TABLE_HEADING_NEW_SHIPPING_ADDRESS', 'Nuovo indirizzo per la spedizione');
define('TEXT_CREATE_NEW_SHIPPING_ADDRESS', 'Usa il seguente modulo per creare un nuovo indirizzo per la spedizione da utilizzare per questo ordine.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Continua la procedura d\' acquisto');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'per selezionare il metodo di pagamento preferito.');
?>