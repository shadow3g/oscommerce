<?php
/*
  $Id: product_reviews.php $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Avis des clients');

define('TEXT_CLICK_TO_ENLARGE', 'Cliquer pour agrandir');

define('TEXT_OF_5_STARS', '%s sur 5 étoiles !');
?>