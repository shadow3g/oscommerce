<?php
/*
  $Id$
 
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
 
  Copyright (c) 2002 osCommerce
 
  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Clienti che ricevono la Newsletter: %s');
define('TEXT_PRODUCTS', 'Prodotti');
define('TEXT_SELECTED_PRODUCTS', 'Prodotti Selezionati');

define('JS_PLEASE_SELECT_PRODUCTS', 'Selezionare i Prodotti.');

define('BUTTON_GLOBAL', 'Globale');
define('BUTTON_SELECT', '>>>');
define('BUTTON_UNSELECT', '<<<');
define('BUTTON_SUBMIT', 'Invia');
define('BUTTON_CANCEL', 'Cancella');
?>
