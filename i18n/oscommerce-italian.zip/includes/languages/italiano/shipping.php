<?php
/*
  $Id: shipping.php,v 1.4 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE', 'Spedizioni e recesso');
define('HEADING_TITLE', 'Spedizioni e recesso');

define('TEXT_INFORMATION', 'Inserire Spedizioni Resi e info qui!');
?>
