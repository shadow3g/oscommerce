<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CATEGORIES_TITLE', 'Catégories');
  define('MODULE_BOXES_CATEGORIES_DESCRIPTION', 'Affiche le bloc de navigation des catégories');
  define('MODULE_BOXES_CATEGORIES_BOX_TITLE', 'Catégories');
?>
