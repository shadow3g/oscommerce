<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Sécurité des Dossiers');

define('TABLE_HEADING_DIRECTORIES', 'Dossier');
define('TABLE_HEADING_WRITABLE', 'Ecriture autorisée');
define('TABLE_HEADING_RECOMMENDED', 'Recommandé');

define('TEXT_DIRECTORY', 'Dossier:');
?>
