<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_USPS_TEXT_TITLE', 'Servicio de Correos de Estados Unidos');
define('MODULE_SHIPPING_USPS_TEXT_DESCRIPTION', 'Servicio de Correos de Estados Unidos<br /><br />Necesita tener registrada una cuenta con USPS en http://www.uspsprioritymail.com/et_regcert.html para utilizar este m&oacute;dulo<br /><br />USPS espera que usted use libras como medida de peso para sus productos.');
define('MODULE_SHIPPING_USPS_TEXT_OPT_PP', 'Servicio de paquetes postales en correos');
define('MODULE_SHIPPING_USPS_TEXT_OPT_PM', 'Prioridad del Env&iacute;o');
define('MODULE_SHIPPING_USPS_TEXT_OPT_EX', 'Env&iacute;o Expreso');
define('MODULE_SHIPPING_USPS_TEXT_ERROR', 'Un error ha ocurrido con los c&aacute;lculos de env&iacute;o de USPS.<br />Si usted prefiere usar USPS como su m&eacute;todo de env&iacute;o, por favor p&oacute;ngase en contacto con el due&ntilde;o de la tienda.');
?>
