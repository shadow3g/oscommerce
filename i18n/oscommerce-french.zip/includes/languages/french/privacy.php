<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Remarque sur la confidentialité');
define('HEADING_TITLE', 'Remarque sur la confidentialité');

define('TEXT_INFORMATION', 'Entrez votre Confidentialité ici! ');
?>
