<?php
/*
  $Id: paypal.php,v 1.7 2002/11/01 05:39:27 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

  define('MODULE_PAYMENT_AGOS_TEXT_TITLE', 'Finanziamento tramite Agos');
  define('MODULE_PAYMENT_AGOS_TEXT_DESCRIPTION', 'Agos');
?>