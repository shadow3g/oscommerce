<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Qui est en ligne');

define('TABLE_HEADING_ONLINE', 'En ligne');
define('TABLE_HEADING_CUSTOMER_ID', 'ID');
define('TABLE_HEADING_FULL_NAME', 'Nom et Prénom');
define('TABLE_HEADING_IP_ADDRESS', 'Adresse IP');
define('TABLE_HEADING_ENTRY_TIME', 'Heure d\'arrivée');
define('TABLE_HEADING_LAST_CLICK', 'Dernier Clic');
define('TABLE_HEADING_LAST_PAGE_URL', 'Dernière URL');
define('TABLE_HEADING_ACTION', 'Action');
define('TABLE_HEADING_SHOPPING_CART', 'Panier utilisateur');
define('TEXT_SHOPPING_CART_SUBTOTAL', 'Sous-total');
define('TEXT_NUMBER_OF_CUSTOMERS', 'Actuellement il y a %s clients en ligne');
?>
