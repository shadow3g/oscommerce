<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Envios');
define('HEADING_TITLE', 'Envios');

define('TEXT_INFORMATION', 'Colocar AQUI as informa��es de Envio.');
?>