<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_LOWORDERFEE_TITLE', 'Taxa de Baixo Valor');
  define('MODULE_ORDER_TOTAL_LOWORDERFEE_DESCRIPTION', 'Taxa de Encomenda de Baixo Valor');
?>