<?php
/*
  $Id: reviews.php $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Avis des clients');
define('HEADING_TITLE', 'Lisez ce que les autres pensent');
define('TEXT_OF_5_STARS', '%s sur 5 étoiles !');
?>