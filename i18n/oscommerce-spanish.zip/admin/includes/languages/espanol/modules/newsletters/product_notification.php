<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Los clientes que reciben boletín: %s');
define('TEXT_PRODUCTS', 'Productos');
define('TEXT_SELECTED_PRODUCTS', 'Productos seleccionados');

define('JS_PLEASE_SELECT_PRODUCTS', 'Por favor seleccione algunos productos.');

define('BUTTON_GLOBAL', 'Global');
define('BUTTON_SELECT', '>>>');
define('BUTTON_UNSELECT', '<<<');
define('BUTTON_SUBMIT', 'Enviar');
define('BUTTON_CANCEL', 'Cancelar');
?>
