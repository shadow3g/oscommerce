<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_FILE_UPLOADS_DISABLED', 'Advertencia: La carga de archivos está  desactivado en el archivo de configuración php.ini.');
?>
