<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_PLUS_ONE_TITLE', 'Google+ +1 Pulsante');
  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_PLUS_ONE_DESCRIPTION', 'Consiglia prodotti attraverso Googlei+ +1 Pulsante.');
  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_PLUS_ONE_PUBLIC_TITLE', 'Raccomanda su Google+');
?>
