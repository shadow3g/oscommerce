<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_TITLE', 'Téléchargements de produits');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_DESCRIPTION', 'Afficher les produits commandés liens de téléchargement sur la page de succès de paiement');

  define('TABLE_HEADING_DOWNLOAD_DATE', 'Date d\'expiration: ');
  define('TABLE_HEADING_DOWNLOAD_COUNT', ' téléchargements restants');
  define('HEADING_DOWNLOAD', 'Téléchargez vos produits ici:');
  define('FOOTER_DOWNLOAD', 'Vous pouvez également télécharger vos produits à une date ultérieure à \'%s\'');
?>
