<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURER_INFO_TITLE', 'Informação  de Marca');
  define('MODULE_BOXES_MANUFACTURER_INFO_DESCRIPTION', 'Mostrar  Informações de Marca');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_TITLE', 'Informação  de Marca');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_HOMEPAGE', 'Página %s');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_OTHER_PRODUCTS', 'Outros Artigos');
?>