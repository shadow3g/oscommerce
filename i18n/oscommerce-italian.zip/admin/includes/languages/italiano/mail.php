<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Spedisci E-Mail ai Clienti');

define('TEXT_CUSTOMER', 'Clienti:');
define('TEXT_SUBJECT', 'Soggetto:');
define('TEXT_FROM', 'Da:');
define('TEXT_MESSAGE', 'Messaggio:');
define('TEXT_SELECT_CUSTOMER', 'Seleziona Cliente');
define('TEXT_ALL_CUSTOMERS', 'Tutti i Clienti');
define('TEXT_NEWSLETTER_CUSTOMERS', 'A tutti gli Iscritti alla Newsletter');

define('NOTICE_EMAIL_SENT_TO', 'Avviso: Email spedita a: %s');
define('ERROR_NO_CUSTOMER_SELECTED', 'Errore: Nessun Cliente selezionato.');
?>
