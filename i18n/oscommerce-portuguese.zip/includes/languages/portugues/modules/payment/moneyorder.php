<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE', 'Cheque');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION', '� Ordem de:&nbsp;' . MODULE_PAYMENT_MONEYORDER_PAYTO . '<br /><br />Enviar para:<br />' . nl2br(STORE_NAME_ADDRESS) . '<br /><br />' . 'A Encomenda s� ser� expedida ap�s boa cobran�a.');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_EMAIL_FOOTER', "� Ordem de: ". MODULE_PAYMENT_MONEYORDER_PAYTO . "\n\nEnviar para:\n" . STORE_NAME_ADDRESS . "\n\n" . 'A Encomenda s� ser� expedida ap�s boa cobran�a.');
?>
