<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Envío');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Costos de envío del pedido');

  define('FREE_SHIPPING_TITLE', 'Envío Gratis');
  define('FREE_SHIPPING_DESCRIPTION', 'Envío gratuito para pedidos superiores %s');
?>
