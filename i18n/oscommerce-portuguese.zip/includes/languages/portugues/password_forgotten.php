<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Entrar');
define('NAVBAR_TITLE_2', 'Recordar Password');

define('HEADING_TITLE', 'Recordar Password!');

define('TEXT_MAIN', 'Se perdeu a sua Password, introduza o seu E-Mail para que possamos enviar-lhe uma nova.');

define('TEXT_NO_EMAIL_ADDRESS_FOUND', 'Erro: O E-Mail fornecido n�o foi encontrado nos registos. Por favor tente de novo.');

define('EMAIL_PASSWORD_REMINDER_SUBJECT', STORE_NAME . ' - Nova Password');
define('EMAIL_PASSWORD_REMINDER_BODY', 'Uma nova password foi pedida por ' . tep_get_ip_address() . '.' . "\n\n" . 'A nova password para \'' . STORE_NAME . '\' �:' . "\n\n" . '   %s' . "\n\n");

define('SUCCESS_PASSWORD_SENT', 'Sucesso: Uma nova password foi enviada para o e-mail.');
?>