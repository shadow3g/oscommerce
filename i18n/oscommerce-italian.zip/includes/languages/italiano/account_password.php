<?php
/*
  $Id: account_password.php,v 1.1 2003/05/19 19:55:45 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'il mio Account');
define('NAVBAR_TITLE_2', 'Cambia Password');

define('HEADING_TITLE', 'Mia Password');

define('MY_PASSWORD_TITLE', 'Mia Password');

define('SUCCESS_PASSWORD_UPDATED', 'La password è stata aggiornata con successo.');
define('ERROR_CURRENT_PASSWORD_NOT_MATCHING', 'La password corrente non corrisponde a quella inserita precedentemente. Riprova.');
?>
