<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT', 'I prodotti che vuoi scaricare non esistono: ' . DIR_FS_DOWNLOAD . '. I prodotti scaricabili non funzioneranno finche sar&agrave; valida questa directory.');
?>
