<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ZONES_TEXT_TITLE', 'Tarifas por Zona');
define('MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION', 'Tarifas basadas en Zonas');
define('MODULE_SHIPPING_ZONES_TEXT_WAY', 'Envío a');
define('MODULE_SHIPPING_ZONES_TEXT_UNITS', 'lb(s)');
define('MODULE_SHIPPING_ZONES_INVALID_ZONE', 'Envíos no disponibles para el país seleccionado');
define('MODULE_SHIPPING_ZONES_UNDEFINED_RATE', 'La tarifa de envío no se puede determinar en este momento');
?>
