<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_ADMIN_LOGIN_TITLE', 'Ingreso a la Herramienta de Administración');
  define('MODULE_ACTION_RECORDER_ADMIN_LOGIN_DESCRIPTION', 'Registro de uso de los inicios de sesión de herramientas de administración.');
?>
