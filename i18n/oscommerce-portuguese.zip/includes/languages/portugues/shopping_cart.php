<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Carrinho de Compras');
define('HEADING_TITLE', 'Conte�do');
define('TABLE_HEADING_REMOVE', 'Remover');
define('TABLE_HEADING_QUANTITY', 'Qtd.');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Artigo(s)');
define('TABLE_HEADING_TOTAL', 'Total');
define('TEXT_CART_EMPTY', 'O carrinho de Compras encontra-se vazio!');
define('SUB_TITLE_SUB_TOTAL', 'Sub-Total:');
define('SUB_TITLE_TOTAL', 'Total:');

define('OUT_OF_STOCK_CANT_CHECKOUT', 'Os Artigos assinalados com ' . STOCK_MARK_PRODUCT_OUT_OF_STOCK . ' n�o existem na quantidade desejada.<br />Por favor, altere a quantidade dos Artigos marcados com (' . STOCK_MARK_PRODUCT_OUT_OF_STOCK . '), Obrigado');
define('OUT_OF_STOCK_CAN_CHECKOUT', 'Os Artigos assinalados com ' . STOCK_MARK_PRODUCT_OUT_OF_STOCK . ' n�o existem na quantidade desejada.<br />Se desejar, pode prosseguir com a Encomenda. Ser� informado com a maior brevidade poss�vel da disponibilidade e quantidade dos Artigos em quest�o. Obrigado.');

define('TEXT_ALTERNATIVE_CHECKOUT_METHODS', '- OU -');
define('TEXT_OR', 'ou ');
define('TEXT_REMOVE', 'remover');
?>
