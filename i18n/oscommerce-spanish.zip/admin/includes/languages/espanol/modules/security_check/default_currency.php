<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('ERROR_NO_DEFAULT_CURRENCY_DEFINED', 'Error: No existe actualmente ningún conjunto de moneda predeterminado. Por favor, establecer uno en: Herramienta de Administración->Localización->Monedas');
?>
