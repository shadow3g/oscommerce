<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_GOOGLE_ADWORDS_CONVERSION_TITLE', 'Google AdWords de seguimiento de conversiones');
  define('MODULE_HEADER_TAGS_GOOGLE_ADWORDS_CONVERSION_DESCRIPTION', 'Añadir Google AdWords de seguimiento de conversiones de la página de pago Éxito');
?>
