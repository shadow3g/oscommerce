<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_TITLE', 'ext/ Listado de Directorio');
define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_HTTP_200', '<a href="' . tep_catalog_href_link('ext/') . '" target="_blank">' . DIR_WS_CATALOG . 'ext/</a> directorio es accesible y / o navegable públicamente - desactive el listado de directorios de este directorio en la configuración del servidor web ');
?>
