<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_REVIEWS_TITLE', 'Avis des clients');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DESCRIPTION', 'Affiche les derniers Avis des clients');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEWER', 'Auteur');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DATE', 'Date');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_RATING', 'Note');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEW_STATUS', 'Etat');
?>
