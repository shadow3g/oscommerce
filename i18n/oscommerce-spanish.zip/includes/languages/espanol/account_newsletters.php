<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Subscripciones a Boletines');

define('HEADING_TITLE', 'Subscripciones a Boletines');

define('MY_NEWSLETTERS_TITLE', 'Mis subscripciones a Boletines');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Boletín General');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Incluye noticias, nuevos productos, ofertas especiales y otros anuncios promocionales.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Sus suscripciones a boletines se han actualizado correctamente.');
?>
