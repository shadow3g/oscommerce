<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Carrinho de Visitante / Carrinho de Cliente');
define('SUB_HEADING_TITLE_1', 'Carrinho de Visitante');
define('SUB_HEADING_TITLE_2', 'Carrinho de Cliente');
define('SUB_HEADING_TITLE_3', 'Informa��o');
define('SUB_HEADING_TEXT_1', 'A cada Visitante da nossa loja on-line � atribu�do um \'Carrinho de Visitante\'. Isto permite que um Visitante coloque os seus Artigos num Carrinho tempor�rio. Assim que sair da loja, o conte�do do Carrinho � apagado.');
define('SUB_HEADING_TEXT_2', 'A cada Cliente da nossa loja on-line � atribu�do um \'Carrinho de Cliente\'. Isto permite que um Cliente coloque  os seus Artigos no Carrinho de Compras e finalize a Encomenda mais tarde. Todos os Artigos permanecer�o no Carrinho at� que os remova ou finalize a Encomenda.');
define('SUB_HEADING_TEXT_3', 'Se um cliente adiconar Artigos ao \'Carrinho de Visitante\' e depois entrar com os Dados Pessoais, todos os Artigos do \'Carrinho de Visitante\' ser�o transferidos para o \'Carrinho de Cliente\' automaticamente.');
define('TEXT_CLOSE_WINDOW', '[ fechar janela ]');
?>