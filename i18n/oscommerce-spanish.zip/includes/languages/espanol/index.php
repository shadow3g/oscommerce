<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_MAIN', '<center> <h1> <b>NUEVA TIENDA ONLINE!</b></h1></center>
');
define('TABLE_HEADING_NEW_PRODUCTS', 'Nuevos Productos para %s');
define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Productos en espera');
define('TABLE_HEADING_DATE_EXPECTED', 'Fecha prevista para');
define('HEADING_TITLE', 'Bienvenido a ' . STORE_NAME);
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Nombre del Producto');
define('TABLE_HEADING_MANUFACTURER', 'Fabricante');
define('TABLE_HEADING_QUANTITY', 'Cantidad');
define('TABLE_HEADING_PRICE', 'Precio');
define('TABLE_HEADING_WEIGHT', 'Peso');
define('TABLE_HEADING_BUY_NOW', 'Comprar Ahora');
define('TEXT_NO_PRODUCTS', 'No hay productos disponibles en esta categoría.');
define('TEXT_NUMBER_OF_PRODUCTS', 'Número de Productos: ');
define('TEXT_SHOW', '<strong>Mostrar:</strong>');
define('TEXT_BUY', 'Comprar 1 \'');
define('TEXT_NOW', '\' ahora');
define('TEXT_ALL_CATEGORIES', 'Todas las Categorías');
define('TEXT_ALL_MANUFACTURERS', 'Todos los fabricantes');
?>
