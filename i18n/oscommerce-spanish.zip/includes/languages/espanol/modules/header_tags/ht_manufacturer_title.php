<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MANUFACTURER_TITLE_TITLE', 'Título de Fabricante');
  define('MODULE_HEADER_TAGS_MANUFACTURER_TITLE_DESCRIPTION', 'Adicionar el título del fabricante actual para el título de la página');
?>
