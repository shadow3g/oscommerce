<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_TITLE', 'Créer un compte Lien');
  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_DESCRIPTION', 'Afficher un récipient créer un compte sur la page de connexion');

  define('MODULE_CONTENT_LOGIN_HEADING_NEW_CUSTOMER', 'Nouveau Client');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER', 'Je suis un nouveau client.');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER_INTRODUCTION', 'En créant un compte auprès de ' . STORE_NAME . ' vous pourrez commander plus vite, d\'être à jour dans vos commandes et de garder trace des commandes que vous avez faites précédemment.');
?>
