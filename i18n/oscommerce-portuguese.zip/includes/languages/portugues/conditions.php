<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Termos de Utilização');
define('HEADING_TITLE', 'Termos de Utilização');

define('TEXT_INFORMATION', 'Qualquer utilizador registado pode encomendar produtos na loja online, desde que esteja de acordo com a nossa politica de utilizacao. Nesta primeira etapa da loja online a Eira do Campones apenas pode garantir a entrega dos seus produtos em Portugal Continental. No entanto se nos encontrou, encontra-se fora de Portuagal continental e deseja receber/provar os nossos produtos, por favor contacte-nos para encontramos uma alternativa de envio para o seu destino. Por exemplo ja nos foi possivel efectuar entregas na Suica e Africa do Sul.');
?>