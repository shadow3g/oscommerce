<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Termos de Privacidade');
define('HEADING_TITLE', 'Termos de Privacidade');

define('TEXT_INFORMATION', 'A Eira do Camponês reserva o direito de poder cancelar qualquer encomenda efectuada na sua loja online. Qualquer dado privado forneceido pelo seus utilizadores,sera tratado de maneira confidencial. A Eira do Camponês nao fonece os dados dos seus utilizadores a outras entidades. Sendo estes dados usados unicamente pela Eira do Camponês para entrega da encomenda efectuada. Na eventualidade de assinar a nossa newsletter recebe periodicamente novidades da nossa loja online.');
?>