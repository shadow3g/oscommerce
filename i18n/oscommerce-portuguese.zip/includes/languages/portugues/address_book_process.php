<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Conta Pessoal');
define('NAVBAR_TITLE_2', 'Livro de Endere�os');

define('NAVBAR_TITLE_ADD_ENTRY', 'Novo');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Actualizar');
define('NAVBAR_TITLE_DELETE_ENTRY', 'Apagar');

define('HEADING_TITLE_ADD_ENTRY', 'Novo Endere�o');
define('HEADING_TITLE_MODIFY_ENTRY', 'Actualizar Endere�o');
define('HEADING_TITLE_DELETE_ENTRY', 'Apagar Endere�o');

define('DELETE_ADDRESS_TITLE', 'Apagar Endere�o');
define('DELETE_ADDRESS_DESCRIPTION', 'Tem a certeza que pretende eliminar os Endere�os seleccionados?');

define('NEW_ADDRESS_TITLE', 'Novo Endere�o');

define('SELECTED_ADDRESS', 'Seleccionar Endere�o');
define('SET_AS_PRIMARY', 'Definir como principal.');

define('SUCCESS_ADDRESS_BOOK_ENTRY_DELETED', 'O Endere�o foi eliminado com sucesso.');
define('SUCCESS_ADDRESS_BOOK_ENTRY_UPDATED', 'O Endere�o foi actualizado com sucesso.');

define('WARNING_PRIMARY_ADDRESS_DELETION', 'O Endere�o Principal n�o pode ser eliminado. Defina outro Endere�o como principal e tente de novo.');

define('ERROR_NONEXISTING_ADDRESS_BOOK_ENTRY', 'O Endere�o n�o existe.');
define('ERROR_ADDRESS_BOOK_FULL', 'O Livro de Endere�os est� cheio. Por favor, elimine Endere�os n�o utilizados para criar um novo.');
?>
