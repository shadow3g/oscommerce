<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_TITLE', 'Configurar Cuenta Contraseña');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_DESCRIPTION', 'Vuelva a colocar la página de cambio de contraseña con la página Establecer contraseña si no hay contraseña de la cuenta local se ha establecido');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_LINK_TITLE', 'Configurar Cuenta Contraseña');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_1', 'mi cuenta');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_2', 'Fijar Contraseña');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_HEADING_TITLE', 'Fijar Contraseña');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_TITLE', 'Fijar Contraseña');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SUCCESS_PASSWORD_SET', 'Su contraseña ha sido guardado con éxito.');
?>
