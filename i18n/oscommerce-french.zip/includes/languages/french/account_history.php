<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mon compte');
define('NAVBAR_TITLE_2', 'Historique');

define('HEADING_TITLE', 'Historique de mes commandes');

define('TEXT_ORDER_NUMBER', 'Numéro de commande :');
define('TEXT_ORDER_STATUS', 'Statut de la commande :');
define('TEXT_ORDER_DATE', 'Date de la commande :');
define('TEXT_ORDER_SHIPPED_TO', 'Expédiée à :');
define('TEXT_ORDER_BILLED_TO', 'Facturé à :');
define('TEXT_ORDER_PRODUCTS', 'Produits :');
define('TEXT_ORDER_COST', 'Coût de la commande :');
define('TEXT_VIEW_ORDER', 'Afficher commande');

define('TEXT_NO_PURCHASES', 'Vous n\'avez pas encore fait d\'achat.');
?>
