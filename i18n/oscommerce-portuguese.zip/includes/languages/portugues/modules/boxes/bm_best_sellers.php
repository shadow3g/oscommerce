<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_BEST_SELLERS_TITLE', 'Top Vendas');
  define('MODULE_BOXES_BEST_SELLERS_DESCRIPTION', 'Mostrar Top Vendas Global e por Categorias');
  define('MODULE_BOXES_BEST_SELLERS_BOX_TITLE', 'Top Vendas');
?>
