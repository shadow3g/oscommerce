<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Conditions d\'utilisation');
define('HEADING_TITLE', 'Conditions d\'utilisation');

define('TEXT_INFORMATION', 'Mettez vos termes et conditions ici! ');
?>
