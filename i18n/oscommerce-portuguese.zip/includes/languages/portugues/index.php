<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_MAIN', '');
define('TABLE_HEADING_NEW_PRODUCTS', 'Novidades de %s');
define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Brevemente');
define('TABLE_HEADING_DATE_EXPECTED', 'Data Prevista');
define('HEADING_TITLE', 'Bem vindo à ' . STORE_NAME);
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Artigo');
define('TABLE_HEADING_MANUFACTURER', 'Marca');
define('TABLE_HEADING_QUANTITY', 'Quantidade');
define('TABLE_HEADING_PRICE', 'Preço');
define('TABLE_HEADING_WEIGHT', 'Peso');
define('TABLE_HEADING_BUY_NOW', 'Comprar');
define('TEXT_NO_PRODUCTS', 'Actualmente não existem Artigos nesta Categoria.');
define('TEXT_NUMBER_OF_PRODUCTS', 'Quantidade: ');
define('TEXT_SHOW', '<strong>Mostrar:</strong>');
define('TEXT_BUY', 'Comprar 1 \'');
define('TEXT_NOW', '\' já');
define('TEXT_ALL_CATEGORIES', 'Todas as Categorias');
define('TEXT_ALL_MANUFACTURERS', 'Todas as Marcas');
?>