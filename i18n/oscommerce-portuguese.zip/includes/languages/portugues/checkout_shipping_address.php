<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Encomendar');
define('NAVBAR_TITLE_2', 'Alterar Endere�o de Envio');

define('HEADING_TITLE', 'Envio');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Endere�o de Envio');
define('TEXT_SELECTED_SHIPPING_DESTINATION', 'Este � o Endere�o de Envio seleccionado para entrega da Encomenda.');
define('TITLE_SHIPPING_ADDRESS', 'Endere�o de Envio:');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Endere�os');
define('TEXT_SELECT_OTHER_SHIPPING_DESTINATION', 'Por favor seleccione um Endere�o de Envio se desejar que a Factura seja enviada para outro local.');
define('TITLE_PLEASE_SELECT', 'Seleccione');

define('TABLE_HEADING_NEW_SHIPPING_ADDRESS', 'Novo Endere�o de Envio');
define('TEXT_CREATE_NEW_SHIPPING_ADDRESS', 'Por favor utilize o formul�rio para criar um novo Endere�o de Envio.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Continuar');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'para seleccionar o M�todo de Envio.');
?>
