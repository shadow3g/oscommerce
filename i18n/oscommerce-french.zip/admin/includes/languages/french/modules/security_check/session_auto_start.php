<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_SESSION_AUTO_START', 'session.auto_start est activé - Veuillez désactiver cette option dans le php.ini et redémarrer le serveur web.');
?>
