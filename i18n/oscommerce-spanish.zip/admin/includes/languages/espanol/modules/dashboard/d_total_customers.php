<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_TOTAL_CUSTOMERS_TITLE', 'Gráfico del Total de Clientes (últimos 30 días)');
define('MODULE_ADMIN_DASHBOARD_TOTAL_CUSTOMERS_DESCRIPTION', 'Mostrar el total de clientes de los últimos 30 días');
define('MODULE_ADMIN_DASHBOARD_TOTAL_CUSTOMERS_CHART_LINK', 'Total Clientes');
?>
