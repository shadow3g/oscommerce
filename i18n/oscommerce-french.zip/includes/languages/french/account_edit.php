<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mon compte');
define('NAVBAR_TITLE_2', 'Modifier compte');

define('HEADING_TITLE', 'Information de mon compte');

define('MY_ACCOUNT_TITLE', 'Mon compte');

define('SUCCESS_ACCOUNT_UPDATED', 'Votre compte a été mis à jour.');
?>
