<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_TITLE', 'Crear Cuenta Enlace');
  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_DESCRIPTION', 'Mostrar un recipiente crear cuenta en la página de inicio de sesión');

  define('MODULE_CONTENT_LOGIN_HEADING_NEW_CUSTOMER', 'Nuevo Cliente');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER', 'Soy un nuevo cliente.');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER_INTRODUCTION', 'Al crear una cuenta en ' . STORE_NAME . ' usted podrá realizar sus compras rapidamente, revisar el estado de sus pedidos y realizar un seguimiento de las órdenes de sus operaciones anteriores.');
?>
