<?php
/*
  modulo di spedizione tramite PostaRaccomandata
  by hOZONE, hozone@tiscali.it, http://hozone.cjb.net

  visita osCommerceITalia, http://www.oscommerceitalia.com
  
  derivato dal modulo:
  $Id: zones.php,v 1.3 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_POSTEPOSTARACCOMANDATA_TEXT_TITLE', 'PostaRaccomandata');
define('MODULE_SHIPPING_POSTEPOSTARACCOMANDATA_TEXT_DESCRIPTION', 'Spedizione tramite PostaRaccomandata');
define('MODULE_SHIPPING_POSTEPOSTARACCOMANDATA_TEXT_WAY', 'Tariffa');
define('MODULE_SHIPPING_POSTEPOSTARACCOMANDATA_INVALID_ZONE', 'Zona di spedizione non coperta');
define('MODULE_SHIPPING_POSTEPOSTARACCOMANDATA_UNDEFINED_RATE', 'Il costo di spedizione non può essere determinato');
?>
