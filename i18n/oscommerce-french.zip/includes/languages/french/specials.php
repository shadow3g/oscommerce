<?php
/*
  $Id: specials.php $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Promotions');
define('HEADING_TITLE', 'Profitez-en tant qu\'ils sont à ce prix !');
?>