<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_TITLE', 'Ultimas conexión del Administrador');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DESCRIPTION', 'Mostrar los últimos inicios de sesión exitosos y fallidos del Administrador');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DATE', 'Fecha');
?>
