<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/
/*
define('HEADING_TITLE_MODULES_PAYMENT', 'Moduli  Pagamento');
define('HEADING_TITLE_MODULES_SHIPPING', 'Moduli  Spedizione');
define('HEADING_TITLE_MODULES_ORDER_TOTAL', 'Moduli  Totale Ordine');
*/
define('TABLE_HEADING_MODULES', 'Moduli');
define('TABLE_HEADING_SORT_ORDER', 'Ordine');
define('TABLE_HEADING_ACTION', 'Azione');

define('TEXT_INFO_VERSION', 'Versione:');
define('TEXT_INFO_ONLINE_STATUS', 'online status');
define('TEXT_INFO_API_VERSION', 'API Versione:');

define('TEXT_MODULE_DIRECTORY', 'Directory Moduli:');
?>
