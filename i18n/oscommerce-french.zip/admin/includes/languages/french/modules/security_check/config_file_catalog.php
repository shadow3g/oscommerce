<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_CONFIG_FILE_WRITEABLE', 'Il est possible d\'écrire dans les fichiers de configuration: ' . DIR_FS_CATALOG . 'includes/configure.php. C\'est une faille de sécurité potentielle - Modifiez les droits sur ce fichier (CHMOD 444).');
?>
