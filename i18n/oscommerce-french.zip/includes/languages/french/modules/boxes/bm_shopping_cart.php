<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SHOPPING_CART_TITLE', 'Panier');
  define('MODULE_BOXES_SHOPPING_CART_DESCRIPTION', 'Affiche le contenu du panier');
  define('MODULE_BOXES_SHOPPING_CART_BOX_TITLE', 'Panier');
  define('MODULE_BOXES_SHOPPING_CART_BOX_CART_EMPTY', 'vide');
?>
