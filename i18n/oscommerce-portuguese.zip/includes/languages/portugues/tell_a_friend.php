<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Recomendar');

define('HEADING_TITLE', 'Recomendar \'%s\'');

define('FORM_TITLE_CUSTOMER_DETAILS', 'Os Seus Detalhes');
define('FORM_TITLE_FRIEND_DETAILS', 'Detalhes do seu Amigo');
define('FORM_TITLE_FRIEND_MESSAGE', 'Messagem');

define('FORM_FIELD_CUSTOMER_NAME', 'Nome:');
define('FORM_FIELD_CUSTOMER_EMAIL', 'E-Mail:');
define('FORM_FIELD_FRIEND_NAME', 'Nome:');
define('FORM_FIELD_FRIEND_EMAIL', 'E-Mail:');

define('TEXT_EMAIL_SUCCESSFUL_SENT', 'O E-mail sobre <strong>%s</strong> foi enviado com sucesso para <strong>%s</strong>.');

define('TEXT_EMAIL_SUBJECT', '%s recomendou-lhe este fabuloso Artigo da loja %s');
define('TEXT_EMAIL_INTRO', 'Ol� %s!' . "\n\n" . '%s, gostaria de lhe recomendar %s da loja %s.');
define('TEXT_EMAIL_LINK', 'Para visualizar este Artigo, clique no link ou copie e cole-o na barra de endere�os do seu browser:' . "\n\n" . '%s');
define('TEXT_EMAIL_SIGNATURE', 'Obrigado,' . "\n\n" . '%s');

define('ERROR_TO_NAME', 'Erro: O Nome tem que ser preenchido.');
define('ERROR_TO_ADDRESS', 'Erro: � necess�rio um E-Mail v�lido.');
define('ERROR_FROM_NAME', 'Erro: O Nome tem que ser preenchido.');
define('ERROR_FROM_ADDRESS', 'Erro: � necess�rio um E-Mail v�lido.');
define('ERROR_ACTION_RECORDER', 'Erro: J� foi enviado um E-Mail. Por favor, tente de novo dentro de %s minutos.');
?>
