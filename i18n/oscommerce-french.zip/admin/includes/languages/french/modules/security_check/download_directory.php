<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT', 'Le répertoire de téléchargement n\'existe pas: ' . DIR_FS_DOWNLOAD . '. Les produits téléchargeables ne fonctionneront pas tant que ce répertoire ne sera pas créé.');
?>
