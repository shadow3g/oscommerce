<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SEARCH_TITLE', 'Ricerca');
  define('MODULE_BOXES_SEARCH_DESCRIPTION', 'Mostra campo ricerca');
  define('MODULE_BOXES_SEARCH_BOX_TITLE', 'Ricerca Veloce');
  define('MODULE_BOXES_SEARCH_BOX_TEXT', 'Usa parole chiave per cercare il prodotto desiderato.');
  define('MODULE_BOXES_SEARCH_BOX_ADVANCED_SEARCH', 'Ricerca avanzata');
?>
