<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Pesquisa Avan�ada');
define('NAVBAR_TITLE_2', 'Resultados');

define('HEADING_TITLE_1', 'Pesquisa Avan�ada');
define('HEADING_TITLE_2', 'Resultados da Pesquisa');

define('HEADING_SEARCH_CRITERIA', 'Crit�rio de Pesquisa');

define('TEXT_SEARCH_IN_DESCRIPTION', 'Pesquisa das Descri��es do Artigo');
define('ENTRY_CATEGORIES', 'Categorias:');
define('ENTRY_INCLUDE_SUBCATEGORIES', 'Incluir Sub-Categorias');
define('ENTRY_MANUFACTURERS', 'Marcas:');
define('ENTRY_PRICE_FROM', 'Pre�o M�nimo:');
define('ENTRY_PRICE_TO', 'Pre�o M�ximo:');
define('ENTRY_DATE_FROM', 'Data Inicial:');
define('ENTRY_DATE_TO', 'Data Final:');

define('TEXT_SEARCH_HELP_LINK', '<u>Ajuda � Pesquisa</u> [?]');

define('TEXT_ALL_CATEGORIES', 'Todas as Categorias');
define('TEXT_ALL_MANUFACTURERS', 'Todas as Marcas');

define('HEADING_SEARCH_HELP', 'Ajuda � Pesquisa');
define('TEXT_SEARCH_HELP', 'As Palavras Chave podem ser separadas por AND e/ou OR para um maior controlo sobre os resultados da pesquisa.<br /><br />Por exemplo, <u>toner AND tinteiro</u> gerar� uma lista de resultados de Artigos que contenham ambos os termos. Por outro lado, <u>toner OR tinteiro</u>, gerar� uma lista de resultados que contenham ambos ou apenas um dos termos.<br /><br />Termos exactos podem ser pesquisados utilizando aspas.<br /><br />Por exemplo, <u>"tinteiro compat�vel"</u> gerar� uma lista de resultados que contenha a express�o exacta entre as aspas.<br /><br />Para um controlo ainda maior dos resultados de pesquisa,podem ser utilizados parentises.<br /><br />Por exemplo, <u>LCortes and (tinteiros and compativeis or "tinteiros reciclados")</u>.');
define('TEXT_CLOSE_WINDOW', '<u>Fechar Janela</u> [x]');

define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Artigo');
define('TABLE_HEADING_MANUFACTURER', 'Marca');
define('TABLE_HEADING_QUANTITY', 'Quantidade');
define('TABLE_HEADING_PRICE', 'Pre�o');
define('TABLE_HEADING_WEIGHT', 'Peso');
define('TABLE_HEADING_BUY_NOW', 'Comprar');

define('TEXT_NO_PRODUCTS', 'N�o h� Artigos que satizfa�am o Crit�rio de Pesquisa.');

define('ERROR_AT_LEAST_ONE_INPUT', 'Pelo menos um campo de pesquisa tem que ser preenchido.');
define('ERROR_INVALID_FROM_DATE', 'Data inicial inv�lida.');
define('ERROR_INVALID_TO_DATE', 'Data final inv�lida.');
define('ERROR_TO_DATE_LESS_THAN_FROM_DATE', 'A Data Final tem que ser igual ou superior � Data Inicial.');
define('ERROR_PRICE_FROM_MUST_BE_NUM', 'O Pre�o M�nimo tem que ser um n�mero.');
define('ERROR_PRICE_TO_MUST_BE_NUM', 'O Pre�o M�ximo tem que ser um n�mero.');
define('ERROR_PRICE_TO_LESS_THAN_PRICE_FROM', 'O Pre�o M�ximo tem que ser maior ou igual ao Pre�o M�nimo.');
define('ERROR_INVALID_KEYWORDS', 'Palavras Chave Inv�lidas.');
?>
