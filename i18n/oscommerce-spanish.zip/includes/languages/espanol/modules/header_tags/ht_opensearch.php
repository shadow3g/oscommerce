<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_OPENSEARCH_TITLE', 'OpenSearch');
  define('MODULE_HEADER_TAGS_OPENSEARCH_DESCRIPTION', 'Permitir al navegador la búsqueda en la tienda a través de OpenSearch');
?>
