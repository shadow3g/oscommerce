<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_TITLE', 'Descargas de productos');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_DESCRIPTION', 'Mostrar ordenado enlaces de descarga del producto en la página de éxito checkout');

  define('TABLE_HEADING_DOWNLOAD_DATE', 'Fecha de caducidad: ');
  define('TABLE_HEADING_DOWNLOAD_COUNT', ' descargas restantes');
  define('HEADING_DOWNLOAD', 'Descargue sus productos aquí:');
  define('FOOTER_DOWNLOAD', 'También puede descargar sus productos en un momento posterior al \'%s\'');
?>
