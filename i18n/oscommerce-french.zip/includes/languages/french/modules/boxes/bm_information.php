<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'Informations');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Affiche les liens des pages dans le bloc Informations');
  define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Informations');
  define('MODULE_BOXES_INFORMATION_BOX_PRIVACY', 'Remarque sur la confidentialité');
  define('MODULE_BOXES_INFORMATION_BOX_CONDITIONS', 'Conditions d\'utilisation');
  define('MODULE_BOXES_INFORMATION_BOX_SHIPPING', 'Expédition &amp; retours');
  define('MODULE_BOXES_INFORMATION_BOX_CONTACT', 'Contactez-nous');
?>
