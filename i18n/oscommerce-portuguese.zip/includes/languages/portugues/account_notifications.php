<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Conta Pessoal');
define('NAVBAR_TITLE_2', 'Notifica��o de Artigos');

define('HEADING_TITLE', 'Notifica��o de artigos');

define('MY_NOTIFICATIONS_TITLE', 'Notifica��es');
define('MY_NOTIFICATIONS_DESCRIPTION', 'As Notifica��es permitem-lhe estar sempre actualizado acerca dos Artigos do seu interesse.<br /><br />Ao seleccionar <strong>Notifica��o Geral</strong> ficar� sempre informado de TODOS os Artigos.');

define('GLOBAL_NOTIFICATIONS_TITLE', 'Notifica��o Geral');
define('GLOBAL_NOTIFICATIONS_DESCRIPTION', 'Receber noticifa��es acerca de todos os Artigos.');

define('NOTIFICATIONS_TITLE', 'Notifica��o de Artigos');
define('NOTIFICATIONS_DESCRIPTION', 'Para remover Notifica��es a determinado Artigo, desmarque a caixa e clique em Continuar.');
define('NOTIFICATIONS_NON_EXISTING', 'N�o existem Notifica��es de Artigos.<br /><br />Para adicionar um Artigo � lista de Notifica��es, clique em Notifica��o, na p�gina de informa��o do Artigo.');

define('SUCCESS_NOTIFICATIONS_UPDATED', 'As Notifica��es foram actualizadas com sucesso.');
?>
