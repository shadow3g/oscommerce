<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_TITLE', 'Réglez compte Mot de passe');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_DESCRIPTION', 'Remplacer Change page de mot de passe avec la page Set de mot de passe si aucun mot de passe de compte local a été mis en');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_LINK_TITLE', 'Réglez compte mot de passe.');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_1', 'Mon Compte');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_2', 'Définir mot de passe');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_HEADING_TITLE', 'Définir mot de passe');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_TITLE', 'Définir mot de passe');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SUCCESS_PASSWORD_SET', 'Votre mot de passe a bien été enregistré.');
?>
