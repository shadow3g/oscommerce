<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Contacte-nos');
define('NAVBAR_TITLE', 'Contacte-nos');
define('TEXT_SUCCESS', 'A sua Mensagem foi enviada com sucesso.');
define('EMAIL_SUBJECT', 'Mensagem de ' . STORE_NAME);

define('ENTRY_NAME', 'Nome:');
define('ENTRY_EMAIL', 'E-Mail:');
define('ENTRY_ENQUIRY', 'Mensagem:');

define('ERROR_ACTION_RECORDER', 'Erro: J� foi enviada uma Mensagem. Por favor tente de novo dentro de %s minutos.');
?>