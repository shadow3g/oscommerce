<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_GOOGLE_ADWORDS_CONVERSION_TITLE', 'Google AdWords Suivi des conversions');
  define('MODULE_HEADER_TAGS_GOOGLE_ADWORDS_CONVERSION_DESCRIPTION', 'Ajouter Google AdWords suivi des conversions à la page Commander succès');
?>
