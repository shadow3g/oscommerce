<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_DIRECTORY_LISTING_TITLE', 'admin/backups/ Elenco di directory');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_DIRECTORY_LISTING_HTTP_200', 'Il <a href="' . tep_href_link('backups/') . '" target="_blank">' . DIR_WS_ADMIN . 'backups/</a> directory è accessibile e/o consultabile pubblicamente - si prega di disabilitare la directory per questa directory nella configurazione del server web.');
?>
