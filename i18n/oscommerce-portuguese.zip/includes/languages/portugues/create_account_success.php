<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Criar Conta Pessoal');
define('NAVBAR_TITLE_2', 'Sucesso');
define('HEADING_TITLE', 'A Conta Pessoal foi criada!');
define('TEXT_ACCOUNT_CREATED', 'Parab�ns! A sua COnta Pessoal foi criada com sucesso! Pode agora utilizar todas os servi�os que temos ao seu dipor. Para <small><strong>QUALQUER</strong></small> quest�o relacionada com o funcionamento da loja on-line, por favor  <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">contacte-nos</a>.<br /><br />Foi enviado uma confirma��o para o E-Mail fornecido. Se n�o o receber no prazo m�ximo de 1h, por favor <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">contacte-nos</a>.');
?>
