<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mon compte');
define('NAVBAR_TITLE_2', 'Changer le mot de passe');

define('HEADING_TITLE', 'Mon mot de passe');

define('MY_PASSWORD_TITLE', 'Mon mot de passe');

define('SUCCESS_PASSWORD_UPDATED', 'Votre mot de passe a été modifié.');
define('ERROR_CURRENT_PASSWORD_NOT_MATCHING', 'Votre nouveau mot de passe doit être différent du mot de passe actuellement enregistré sur notre site. Veuillez réessayer.');
?>
