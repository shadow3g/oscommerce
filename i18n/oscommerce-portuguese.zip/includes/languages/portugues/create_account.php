<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Criar Conta Pessoal');

define('HEADING_TITLE', 'Conta Pessoal');

define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><strong>NOTA:</strong></small></font> Se j� possui uma Conta Pessoal, por favor introduza os seus dados <a href="%s"><u>aqui</u></a>.');

define('EMAIL_SUBJECT', 'Bem vindo � ' . STORE_NAME);
define('EMAIL_GREET_MR', 'Caro Sr.. %s,' . "\n\n");
define('EMAIL_GREET_MS', 'Cara Sra.. %s,' . "\n\n");
define('EMAIL_GREET_NONE', 'Caro %s' . "\n\n");
define('EMAIL_WELCOME', 'Bem vindo � <strong>' . STORE_NAME . '</strong>.' . "\n\n");
define('EMAIL_TEXT', '<strong>Bem vindo</strong>. A partir de agora pode utilizar todas as funcionalidades da loja on-line. Destacamos:' . "\n\n" . '<li><strong>Carrinho Permanente</strong> - Todos os Artigos adiconados permanecer�o no Carrinho de Compras at� que sejam apagados ou encomendados.' . "\n" . '<li><strong>Livro de Endere�os</strong> - Pode enviar as suas encomendas para outro Endere�o que n�o o seu! Torna-se extremamente �til para empresas que pretendam enviar as Encomendas para as filiais, ou para enviar um presente directamente para o aniversariante.' . "\n" . '<li><strong>Hist�rico de Encomendas</strong> - Mantem um registo de todas as Encomendas.' . "\n" . '<li><strong>Coment�rios</strong> - Partilhe opini�es acerca dos Artigos da loja.' . "\n\n");
define('EMAIL_CONTACT', 'Se necessitar de ajuda na utiliza��o da loja on-line, por favor contacte-nos: ' . STORE_OWNER_EMAIL_ADDRESS . '.' . "\n\n");
define('EMAIL_WARNING', '<strong>Note:</strong> Este endere�o de E-Mail foi-nos fornecido por um dos nossos clientes. Se n�o se inscreveu na nossa loja on-line, por favor informe-nos atrav�s do E-Mail ' . STORE_OWNER_EMAIL_ADDRESS . '.' . "\n");
?>
