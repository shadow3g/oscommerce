<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Comentários');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Mostrar Comentários de Artigos');
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Comentários');
  define('MODULE_BOXES_REVIEWS_BOX_WRITE_REVIEW', 'Adicionar um comentário a este Artigo!');
  define('MODULE_BOXES_REVIEWS_BOX_NO_REVIEWS', 'Não existem comentários');
  define('MODULE_BOXES_REVIEWS_BOX_TEXT_OF_5_STARS', '%s de 5 Estrelas!');
?>