<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_ORDER_HISTORY_TITLE', 'Storico Ordine');
  define('MODULE_BOXES_ORDER_HISTORY_DESCRIPTION', 'Mostra i prodotti ordinati in precedenza dal cliente registrato');
  define('MODULE_BOXES_ORDER_HISTORY_BOX_TITLE', 'Storico Ordine');
?>
