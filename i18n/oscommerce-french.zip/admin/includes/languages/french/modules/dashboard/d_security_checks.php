<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_TITLE', 'Contrôle de sécurité');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_DESCRIPTION', 'Lancer le contrôle de la sécurité du site');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_SUCCESS', 'Votre site osCommerce Online Merchant est correctement configuré!');
?>
