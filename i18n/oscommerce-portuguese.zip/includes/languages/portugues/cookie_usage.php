<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Cookies');
define('HEADING_TITLE', 'Cookies');

define('TEXT_INFORMATION', 'O seu browser n�o suporta Cookies, ou est�o desactivados.<br /><br />Para utilizar a loja on-line, � necess�ria a utiliza��o de Cookies.<br /><br />Para activar no <strong>Internet Explorer</strong>:<br /><ol><li>Clique em Ferramentas e seleccione Op��es da Internet</li><li>Seleccione o separador Seguran�a, defina o nivel de seguran�a para M�dio</li></ol>Esta � uma medida para aumentar a seguran�a.<br /><br />Se tiver alguma quest�o, entre em contacto connosco.');

define('BOX_INFORMATION_HEADING', 'Privacidade e Seguran�a dos Cookies');
define('BOX_INFORMATION', 'Os Cookies t�m que ser activados para a utiliza��o da loja on-line como medida para aumentar a seguran�a e privacidade.<br /><br />Ao activar o suporte para Cookies, a seguran�a na comunica��o � aumentada, garantindo a privacidade do utilizador.');
?>
