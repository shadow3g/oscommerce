<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_CONFIG_FILE_WRITEABLE', 'Sono abilitato a scrivere nel file di configurazione: ' . DIR_FS_CATALOG . 'includes/configure.php. Quseto file � potenzialmente un rischio per il tuo sito - Setta i permessi giusti per questo file.');
?>
