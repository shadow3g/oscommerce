<?php
/*
  $Id: products_new.php,v 1.3 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE', 'Nuovi prodotti');
define('HEADING_TITLE', 'Nuovi prodotti');

define('TEXT_DATE_ADDED', 'Aggiunto il:');
define('TEXT_MANUFACTURER', 'Produttore:');
define('TEXT_PRICE', 'Prezzo:');
?>