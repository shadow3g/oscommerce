<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_LOGIN_FORM_TITLE', 'Login Form');
  define('MODULE_CONTENT_LOGIN_FORM_DESCRIPTION', 'Mostra un modulo di login nella pagina di login');

  define('MODULE_CONTENT_LOGIN_HEADING_RETURNING_CUSTOMER', 'Tornando clienti');
  define('MODULE_CONTENT_LOGIN_TEXT_RETURNING_CUSTOMER', 'Sono un cliente abituale.');
  define('MODULE_CONTENT_LOGIN_TEXT_PASSWORD_FORGOTTEN', 'Hai dimenticato la password? Clicca qui.');

  define('MODULE_CONTENT_LOGIN_TEXT_LOGIN_ERROR', 'Errore: Nessuna corrispondenza per indirizzo e/o password E-Mail.');
?>
