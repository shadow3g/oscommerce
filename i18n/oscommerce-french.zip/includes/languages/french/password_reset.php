<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Connexion');
define('NAVBAR_TITLE_2', 'Mot de passe Réinitialiser');

define('HEADING_TITLE', 'Mot de passe Réinitialiser');

define('TEXT_MAIN', 'S\'il vous plaît entrer un nouveau mot de passe pour votre compte.');

define('TEXT_NO_RESET_LINK_FOUND', 'Erreur: Le lien de réinitialisation de mot de passe n\'a pas été trouvé dans nos dossiers, veuillez réessayer en créant un nouveau lien.');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', 'Erreur: L\'adresse E-Mail n\'a pas été trouvé dans nos dossiers, veuillez réessayer.');

define('SUCCESS_PASSWORD_RESET', 'Votre mot de passe a été mis à jour avec succès. S\'il vous plaît vous connecter avec votre nouveau mot de passe.');
?>
