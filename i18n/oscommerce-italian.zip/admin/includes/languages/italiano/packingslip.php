<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Commenti');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Modelli');
define('TABLE_HEADING_PRODUCTS', 'Prodotti');

define('ENTRY_SOLD_TO', 'VENDUTO A:');
define('ENTRY_SHIP_TO', 'SPEDITO A:');
define('ENTRY_PAYMENT_METHOD', 'Metodo di pagamento:');
?>
