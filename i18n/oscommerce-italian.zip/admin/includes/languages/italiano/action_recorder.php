<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Registro Azioni');

define('TABLE_HEADING_MODULE', 'Modulo');
define('TABLE_HEADING_CUSTOMER', 'Cliente');
define('TABLE_HEADING_DATE_ADDED', 'Data');
define('TABLE_HEADING_ACTION', 'Azione');

define('TEXT_FILTER_SEARCH', 'Cerca:');
define('TEXT_ALL_MODULES', '-- Tutti i Moduli --');
define('TEXT_GUEST', 'Guest');

define('TEXT_INFO_IDENTIFIER', 'Identificazione:');
define('TEXT_INFO_DATE_ADDED', 'Aggiunto in data:');

define('SUCCESS_EXPIRED_ENTRIES', 'Successo: %s le entrate scadute sono state rimosse.');
?>