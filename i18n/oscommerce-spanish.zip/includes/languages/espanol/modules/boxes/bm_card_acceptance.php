<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CARD_ACCEPTANCE_TITLE', 'Aceptación de tarjetas');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DESCRIPTION', 'Mostrar logotipos de aceptación de tarjetas de pago');

  define('MODULE_BOXES_CARD_ACCEPTANCE_SHOWN_CARDS', 'tarjetas mostradas');
  define('MODULE_BOXES_CARD_ACCEPTANCE_NEW_CARDS', 'Nuevas Tarjetas');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DRAG_HERE', 'arrastre Aquí');

  define('MODULE_BOXES_CARD_ACCEPTANCE_BOX_TITLE', 'Aceptamos');
?>
