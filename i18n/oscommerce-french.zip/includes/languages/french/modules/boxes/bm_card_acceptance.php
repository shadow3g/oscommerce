<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CARD_ACCEPTANCE_TITLE', 'Acceptation de la carte');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DESCRIPTION', 'Voir carte de paiement logos d\'acceptation');

  define('MODULE_BOXES_CARD_ACCEPTANCE_SHOWN_CARDS', 'Les cartons');
  define('MODULE_BOXES_CARD_ACCEPTANCE_NEW_CARDS', 'Nouvelles cartes');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DRAG_HERE', 'Faites glisser ici');

  define('MODULE_BOXES_CARD_ACCEPTANCE_BOX_TITLE', 'Nous acceptons');
?>
