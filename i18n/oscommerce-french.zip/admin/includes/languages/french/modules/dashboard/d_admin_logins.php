<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_TITLE', 'Dernières connexions administrateurs');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DESCRIPTION', 'Affiche les dernières tentatives de connexions à l\'administration (réussies ou échouées)');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DATE', 'Date');
?>
