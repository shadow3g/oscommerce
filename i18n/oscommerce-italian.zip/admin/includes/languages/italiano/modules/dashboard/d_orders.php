<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ORDERS_TITLE', 'Ordini');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DESCRIPTION', 'Mostra gli ultimi ordini');
define('MODULE_ADMIN_DASHBOARD_ORDERS_TOTAL', 'Totale');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DATE', 'Data');
define('MODULE_ADMIN_DASHBOARD_ORDERS_ORDER_STATUS', 'Stato Ordini');
?>
