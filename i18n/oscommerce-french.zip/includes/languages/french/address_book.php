<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mon compte');
define('NAVBAR_TITLE_2', 'Carnet d\'adresses');

define('HEADING_TITLE', 'Carnet d\'adresses personnel');

define('PRIMARY_ADDRESS_TITLE', 'Adresse principale');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Cette adresse est employée comme adresse principale d\'expédition et de facturation pour des commandes passées sur ce magasin.<br /><br />Cette adresse est également employée comme base pour le produit et les calculs d\'imp&ocirc;ts sur le service.');

define('ADDRESS_BOOK_TITLE', 'Entrées du carnet d\'adresses');

define('PRIMARY_ADDRESS', '(Adresse principale)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><strong>REMARQUE :</strong></font> Un maximum de %s entrées dans le carnet d\'adresses est autorisé.');
?>
