<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURER_INFO_TITLE', 'Información del Fabricante');
  define('MODULE_BOXES_MANUFACTURER_INFO_DESCRIPTION', 'Mostrar información del fabricante en la página de información del producto');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_TITLE', 'Información del Fabricante');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_HOMEPAGE', '%s Página Principal');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_OTHER_PRODUCTS', 'Otros productos');
?>
