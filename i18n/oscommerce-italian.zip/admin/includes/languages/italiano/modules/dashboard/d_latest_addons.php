<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_TITLE', 'Ultimi Componenti aggiuntivi');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DESCRIPTION', 'Mostra gli ultimi componenti aggiuntivi di osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DATE', 'Data');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_FEED_ERROR', 'Non posso connettermi ai feed per i componenti aggiuntivi di osCommerce. Il prossimo tentativo verr&agrave; effettuato tra 24 ore.');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_RSS', 'Registrati ai feed per i Componenti aggiuntivi di osCommerce');
// added for 2.3.4 bof
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_SITE', 'Visita osCommerce Pagina supplementare');
// added for 2.3.4 eof

?>
