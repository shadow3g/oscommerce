<?php
/*
  $Id: address_book.php,v 1.7 2003/05/19 20:17:50 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce 

  Released under the GNU General Public License 
*/

define('NAVBAR_TITLE_1', 'Il mio account');
define('NAVBAR_TITLE_2', 'Rubrica');

define('HEADING_TITLE', 'Rubrica personale');

define('PRIMARY_ADDRESS_TITLE', 'Indirizzo primario');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Questo indirizzo è quello pre-selezionato al momento della scelta delle modalità di acquisto e spedizione degli ordini fatti dal sito.<br><br>E\' anche usato come indirizzo base per il calcolo delle tasse da applicare al prodotto.');

define('ADDRESS_BOOK_TITLE', 'Elenco degli indirizzi');

define('PRIMARY_ADDRESS', '(indirizzo primario)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTA:</b></font> E\' consentito un massimo di %s indirizzi.');
?>