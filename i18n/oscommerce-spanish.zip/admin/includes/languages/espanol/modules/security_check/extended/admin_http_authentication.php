<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_TITLE', 'HTTP de autenticación Admin');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_ERROR', 'La autenticación HTTP no se ha establecido para la herramienta de administración de osCommerce - por favor instalar esto en la configuración de su servidor web para proteger aún más la herramienta de administración de accesos no autorizados.');
?>
