<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'Información');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Mostrar enlaces de información de página');
  define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Información');
  define('MODULE_BOXES_INFORMATION_BOX_PRIVACY', 'Confidencialidad');
  define('MODULE_BOXES_INFORMATION_BOX_CONDITIONS', 'Condiciones de Uso');
  define('MODULE_BOXES_INFORMATION_BOX_SHIPPING', 'Envíos y Devoluciones');
  define('MODULE_BOXES_INFORMATION_BOX_CONTACT', 'Contáctenos');
?>
