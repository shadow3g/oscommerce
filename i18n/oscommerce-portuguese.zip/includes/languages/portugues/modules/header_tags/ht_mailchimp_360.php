<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_MAILCHIMP_360_TITLE', 'MailChimp E-Commerce 360');
  define('MODULE_HEADER_TAGS_MAILCHIMP_360_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="http://eepurl.com/bxza1" target="_blank" style="text-decoration: underline; font-weight: bold;">Visite o site MailChimp</a>&nbsp;<a href="javascript:toggleDivBlock(\'mailchimpInfo\');">(info)</a><span id="mailchimpInfo" style="display: none;"><br /><i>Ao efectuar o registo no MailChimp oferece uma pequena ajuda financeira ao osCommerce por referenciar um cliente.</i></span><br /><br />O m�dulo MailChimp E-Commerce 360 analiza o ROI da suas campanhas de e-mail MailChimp');
?>
