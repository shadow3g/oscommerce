<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Encomendar');
define('NAVBAR_TITLE_2', 'M�todo de Envio');

define('HEADING_TITLE', 'Envio');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Endere�o de Envio');
define('TEXT_CHOOSE_SHIPPING_DESTINATION', 'Por favor seleccione um Endere�o de Envio para a Encomenda.');
define('TITLE_SHIPPING_ADDRESS', 'Endere�o de Envio:');

define('TABLE_HEADING_SHIPPING_METHOD', 'M�todo de Envio');
define('TEXT_CHOOSE_SHIPPING_METHOD', 'Por favor seleccione o M�todo de Envio para esta Encomenda.');
define('TITLE_PLEASE_SELECT', 'Seleccione');
define('TEXT_ENTER_SHIPPING_INFORMATION', 'Este � o �nico M�todo de Envio disponivel para a Encomenda.');

define('TABLE_HEADING_COMMENTS', 'Adicionar Coment�rios');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Continuar');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'para M�todo de Pagamento.');
?>
