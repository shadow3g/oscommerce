<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Avis des clients');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Affiche les avis des clients ');
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Avis des clients');
  define('MODULE_BOXES_REVIEWS_BOX_WRITE_REVIEW', 'Donnez votre avis sur ce produit !');
  define('MODULE_BOXES_REVIEWS_BOX_NO_REVIEWS', 'Il n\'y a pas encore d\'avis sur ce produit');
  define('MODULE_BOXES_REVIEWS_BOX_TEXT_OF_5_STARS', '%s sur 5 étoiles !');
?>
