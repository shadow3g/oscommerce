<?php
/*
  $Id: products_new.php $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Nouveaux produits');
define('HEADING_TITLE', 'Nouveaux produits');

define('TEXT_DATE_ADDED', 'Ajouté le :');
define('TEXT_MANUFACTURER', 'Fabricant :');
define('TEXT_PRICE', 'Prix :');
?>