<?php
/*
  $Id: cookie_usage.php,v 1.1 2003/03/10 23:32:20 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Uso dei Cookie');
define('HEADING_TITLE', 'Uso dei Cookie');

define('TEXT_INFORMATION', 'Abbiamo notato che il tuo browser non supporta i cookies, o questi sono stati disabilitati.<br><br>Per continuare a comprare on-line ti consigliamo di abilitare il supporto per i cookies del tuo browser.<br><br>Per i browser della famiglia <b>Internet Explorer</b>, segio le seguenti istruzioni:<br><ol><li>Clicca sul menu Strumenti, e selezioni Opzioni Internet</li><li>Seleziona Privacy, e resetta il livello di sicurezza a Medio</li></ol>Stiamo prenderndo queste misure di controllo per la vostra sicurezza e non ci rendiamo responsabili di ogni disfunzione legata a questo consiglio.<br><br>Contattaci se hai domande relative a questo requisito, oppure continua a comprare prodotti offline.');

define('BOX_INFORMATION_HEADING', 'Cookie, Privacy e Sicurezza');
define('BOX_INFORMATION', 'Il supporto Cookies deve essere abilitato per comprare online su questo negozio per to garantire la privacy e la sicurezza nella visita sul sito.<br><br>Abilitando il supporto ai cookies sul tuo browser potrà avvenire la comunicazione tra il nostro sito e il tuo computer, garantenzo la vostra e la nostra privacy e sicurezza, e un sicuro scambio di informazioni.');
?>
