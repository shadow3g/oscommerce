<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Cambiar Contraseña');

define('HEADING_TITLE', 'Mi Contraseña');

define('MY_PASSWORD_TITLE', 'Mi Contraseña');

define('SUCCESS_PASSWORD_UPDATED', 'Su contraseña ha sido actualizada correctamente.');
define('ERROR_CURRENT_PASSWORD_NOT_MATCHING', 'Su contraseña actual no coincide con la contraseña en nuestros registros. Por favor, inténtelo de nuevo.');
?>
