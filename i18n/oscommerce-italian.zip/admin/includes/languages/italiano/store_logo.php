<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Logo Negozio');

define('TEXT_LOGO_IMAGE', 'Nuovo Logo:');
define('TEXT_FORMAT_AND_LOCATION', 'Il logo del negozio deve essere in formato PNG e verr&agrave; salvato come:');

define('SUCCESS_LOGO_UPDATED', 'Perfetto: Il logo del negozio è stato aggiornato!');

define('ERROR_IMAGES_DIRECTORY_NOT_WRITEABLE', 'Errore: Non &egrave; possibile aggiungere immagini alla cartella IMAGES. (<a href="%s">clicca qui per modificare i permessi della cartella</a>)');
?>
