<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Conta Pessoal');
define('NAVBAR_TITLE_2', 'Hist�rico');
define('NAVBAR_TITLE_3', 'Encomenda N.�%s');

define('HEADING_TITLE', 'Informa��o de Encomenda');

define('HEADING_ORDER_NUMBER', 'Encomenda N.�%s');
define('HEADING_ORDER_DATE', 'Data:');
define('HEADING_ORDER_TOTAL', 'Total:');

define('HEADING_DELIVERY_ADDRESS', 'Endere�o de Entrega');
define('HEADING_SHIPPING_METHOD', 'M�todo de Envio');

define('HEADING_PRODUCTS', 'Artigos');
define('HEADING_TAX', 'IVA');
define('HEADING_TOTAL', 'Total');

define('HEADING_BILLING_INFORMATION', 'Informa��o Factura��o');
define('HEADING_BILLING_ADDRESS', 'Endere�o de Factura��o');
define('HEADING_PAYMENT_METHOD', 'M�todo de Pagamento');

define('HEADING_ORDER_HISTORY', 'Hist�rico de Encomendas');
define('HEADING_COMMENT', 'Coment�rios');
define('TEXT_NO_COMMENTS_AVAILABLE', 'N�o existem coment�rios.');

define('TABLE_HEADING_DOWNLOAD_DATE', 'O Link expira: ');
define('TABLE_HEADING_DOWNLOAD_COUNT', ' downloads disponiveis');
define('HEADING_DOWNLOAD', 'Download links');
?>
