<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_TITLE', 'Grazie');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_THANK_YOU_DESCRIPTION', 'Mostra ringrazio bloccare sulla pagina di checkout successo.');

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SUCCESS', 'Il tuo ordine è stato elaborato con successo! I vostri prodotti arriveranno a destinazione entro 2-5 giorni lavorativi.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SEE_ORDERS', 'È possibile visualizzare lo stato del tuo ordine in qualsiasi momento nel tuo account<a href="%s">Visualizza ordini</a> pagina.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_CONTACT_STORE_OWNER', 'Si prega di inoltrare tutte le domande che potete avere per noi il nostro <a href="%s">Contattaci</a> pagina.');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_THANKS_FOR_SHOPPING', 'Grazie per l\'acquisto con noi on-line!');
?>
