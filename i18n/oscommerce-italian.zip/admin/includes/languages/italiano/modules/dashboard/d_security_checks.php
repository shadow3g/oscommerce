<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_TITLE', 'Controllo Sicurezza');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_DESCRIPTION', 'Avvia controllo sicurezza');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_SUCCESS', 'Questa installazione &egrave; stata correttamente configurata per osCommerce Online Merchant!');
?>
