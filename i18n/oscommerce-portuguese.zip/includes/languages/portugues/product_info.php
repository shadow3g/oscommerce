<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_PRODUCT_NOT_FOUND', 'Artigo n�o encontrado!');
define('TEXT_CURRENT_REVIEWS', 'Coment�rios:');
define('TEXT_MORE_INFORMATION', 'Para mais informa��es, visite a <a href="%s" target="_blank"><u>p�gina do artigo</u></a>.');
define('TEXT_DATE_ADDED', 'Adicionado em %s.');
define('TEXT_DATE_AVAILABLE', '<font color="#ff0000">Previs�o de disponibilidade: %s.</font>');
define('TEXT_ALSO_PURCHASED_PRODUCTS', 'Clientes que compraram este Artigo tamb�m compraram');
define('TEXT_PRODUCT_OPTIONS', 'Op��es:');
define('TEXT_CLICK_TO_ENLARGE', 'Clique para aumentar');
?>
