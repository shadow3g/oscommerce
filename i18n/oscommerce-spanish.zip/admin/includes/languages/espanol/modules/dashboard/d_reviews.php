<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_REVIEWS_TITLE', 'Comentarios');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DESCRIPTION', 'Mostrar los últimos comentarios');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEWER', 'Revisor/Crítico');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DATE', 'Fecha');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_RATING', 'Clasificación');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEW_STATUS', 'Estado');
?>
