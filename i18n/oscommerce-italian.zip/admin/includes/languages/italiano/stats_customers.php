<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Tutti gli Ordini del miglior Cliente');

define('TABLE_HEADING_NUMBER', 'Num.');
define('TABLE_HEADING_CUSTOMERS', 'Clienti');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Acquisti Totali');
?>
