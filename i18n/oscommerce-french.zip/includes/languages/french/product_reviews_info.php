<?php
/*
  $Id: product_reviews_info.php $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Avis des clients');
define('HEADING_TITLE', ' %s avis');
define('SUB_TITLE_PRODUCT', 'Produit :');
define('SUB_TITLE_FROM', 'De :');
define('SUB_TITLE_DATE', 'Date :');
define('SUB_TITLE_REVIEW', 'Avis :');
define('SUB_TITLE_RATING', 'Classement :');
define('TEXT_OF_5_STARS', '%s sur 5 étoiles !');
define('TEXT_CLICK_TO_ENLARGE', 'Cliquer pour agrandir ');
?>