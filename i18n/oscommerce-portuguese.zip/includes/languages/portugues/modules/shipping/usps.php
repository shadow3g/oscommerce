<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_USPS_TEXT_TITLE', 'United States Postal Service');
define('MODULE_SHIPPING_USPS_TEXT_DESCRIPTION', 'United States Postal Service<br /><br />� necess�ria a inscri��o em http://www.uspsprioritymail.com/et_regcert.html para utilizar este m�dulo<br /><br />USPS utiliza "libras" como medida de peso.');
define('MODULE_SHIPPING_USPS_TEXT_OPT_PP', 'Envio Parcelar');
define('MODULE_SHIPPING_USPS_TEXT_OPT_PM', 'Envio Priorit�rio');
define('MODULE_SHIPPING_USPS_TEXT_OPT_EX', 'Envio Expresso');
define('MODULE_SHIPPING_USPS_TEXT_ERROR', 'Ocorreu um erro a calcular o envio pela USPS.<br />Se deseja utilizar a USPS como meio de envio, contacte o Administrador da loja.');
?>
