<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_TITLE', 'Modules complémentaires');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DESCRIPTION', 'Affiche les derniers modules complémentaires osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DATE', 'Date');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_FEED_ERROR', 'Connexion impossible au flux des nouveaux modules osCommerce. La prochaines tentative sera effectuée dans 24 heures.');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_RSS', 'S\'abonner au flux RSS des modules complémentaires osCommerce');
// added for 2.3.4 bof 
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_SITE', 'Visitez le osCommerce Add-Ons site'); 
// added for 2.3.4 eof 
?>
