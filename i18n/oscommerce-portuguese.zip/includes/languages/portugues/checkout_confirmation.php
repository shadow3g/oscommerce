<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Encomendar');
define('NAVBAR_TITLE_2', 'Confirma��o');

define('HEADING_TITLE', 'Confirma��o da Encomenda');

define('HEADING_SHIPPING_INFORMATION', 'Envio');
define('HEADING_DELIVERY_ADDRESS', 'Endere�o de Entrega');
define('HEADING_SHIPPING_METHOD', 'M�todo de Envio');
define('HEADING_PRODUCTS', 'Artigos');
define('HEADING_TAX', 'IVA');
define('HEADING_TOTAL', 'Total');
define('HEADING_BILLING_INFORMATION', 'Factura��o');
define('HEADING_BILLING_ADDRESS', 'Endere�o de Factura��o');
define('HEADING_PAYMENT_METHOD', 'M�todo de Pagamento');
define('HEADING_PAYMENT_INFORMATION', 'Pagamento');
define('HEADING_ORDER_COMMENTS', 'Coment�rios');

define('TEXT_EDIT', 'Editar');
?>
