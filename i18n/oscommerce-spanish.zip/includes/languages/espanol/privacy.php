<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Confidencialidad');
define('HEADING_TITLE', 'Confidencialidad');

define('TEXT_INFORMATION', 'Introduzca sus condiciones de uso aquí!
');
?>
