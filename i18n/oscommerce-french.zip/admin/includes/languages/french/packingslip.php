<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Commentaires');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Réf/Modèle');
define('TABLE_HEADING_PRODUCTS', 'Produits');

define('ENTRY_SOLD_TO', 'Facturé à:');
define('ENTRY_SHIP_TO', 'Expédié à:');
define('ENTRY_PAYMENT_METHOD', 'Mode de paiement:');
?>
