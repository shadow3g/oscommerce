<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_TITLE', 'ext/ Inscription dans l\'annuaire');
define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_HTTP_200', 'Le <a href="' . tep_catalog_href_link('ext/') . '" target="_blank">' . DIR_WS_CATALOG . 'ext/</a> épertoire est accessible au public et / ou consultable - s\'il vous plaît désactiver la liste des répertoires de ce répertoire dans la configuration de votre serveur web');
?>
