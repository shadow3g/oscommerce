<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_PAYPAL_LOGIN_TITLE', 'Connettiti con PayPal');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DESCRIPTION', 'Attiva il login con PayPal con cassa trasparente per i pagamenti PayPal Express Checkout
<br /><br /><img src="images/icon_info.gif" border="0" />&nbsp;<a href="http://library.oscommerce.com/Package&en&paypal&oscom23&log_in" target="_blank" style="text-decoration: underline; font-weight: bold;">Visualizza Documentazione in linea</a><br /><br /><img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.paypal.com" target="_blank" style="text-decoration: underline; font-weight: bold;">Visita il sito web PayPal</a>');

  define('MODULE_CONTENT_PAYPAL_LOGIN_TEMPLATE_TITLE', 'Connettiti con PayPal');
  define('MODULE_CONTENT_PAYPAL_LOGIN_TEMPLATE_CONTENT', 'Avete un conto PayPal? Saldamente il login con PayPal per acquistare ancora più veloce!');
  define('MODULE_CONTENT_PAYPAL_LOGIN_TEMPLATE_SANDBOX', 'Test Mode: Il server Sandbox è attualmente selezionato.');

  define('MODULE_CONTENT_PAYPAL_LOGIN_ERROR_ADMIN_CURL', 'Questo modulo richiede cURL sia abilitato in PHP e non caricherà fino a quando non è stato abilitato sul server web.');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ERROR_ADMIN_CONFIGURATION', 'Questo modulo non viene caricato fino a quando sono state configurate il Client ID e parametri segreti. Si prega di modificare e configurare le impostazioni di questo modulo.');

  define('MODULE_CONTENT_PAYPAL_LOGIN_LANGUAGE_LOCALE', 'it_IT');

  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_GROUP_personal', 'Informazioni Personali');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_GROUP_address', 'Indirizzo Informazioni');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_GROUP_account', 'Informazioni account');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_GROUP_checkout', 'Pagamento espresso');

  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_full_name', 'Nome e cognome');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_date_of_birth', 'Data di nascita');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_age_range', 'Gamma di età');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_gender', 'Genere');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_email_address', 'Indirizzo e-mail');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_street_address', 'Indirizzo');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_city', 'Città');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_state', 'Stato');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_country', 'Paese');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_zip_code', 'CAP');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_phone', 'Telefono');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_account_status', 'Stato account (verificato)');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_account_type', 'Tipo di account');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_account_creation_date', 'Conto Data di creazione');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_time_zone', 'Fuso orario');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_locale', 'Località');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_language', 'Lingua');
  define('MODULE_CONTENT_PAYPAL_LOGIN_ATTR_seamless_checkout', 'Seamless Checkout');

  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_LINK_TITLE', 'Connection API Test Server');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_TITLE', 'Test di connessione API Server');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_GENERAL_TEXT', 'La connessione al server di prova ..');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_BUTTON_CLOSE', 'Vicino');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_TIME', 'Tempo di connessione:');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_SUCCESS', 'Successo!');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_FAILED', 'Impossibile! Si prega di rivedere le impostazioni verificare il certificato SSL e riprovare.');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_CONNECTION_ERROR', 'Si è verificato un errore. Si prega di aggiornare la pagina, rivedere le impostazioni e riprovare.');

  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_URLS_LINK_TITLE', 'Mostra URL PayPal applicazione');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_URLS_TITLE', 'URL PayPal applicazioni');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_URLS_RETURN_TEXT', 'Redirect/Ritorno URL:');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_URLS_PRIVACY_TEXT', 'Privacy Policy URL:');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_URLS_TERMS_TEXT', 'Accordo per gli utenti URL:');
  define('MODULE_CONTENT_PAYPAL_LOGIN_DIALOG_URLS_BUTTON_CLOSE', 'Vicino');
?>
