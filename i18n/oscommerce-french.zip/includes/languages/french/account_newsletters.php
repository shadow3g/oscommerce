<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mon compte');
define('NAVBAR_TITLE_2', 'Abonnement aux bulletins d\'information');

define('HEADING_TITLE', 'Abonnement aux bulletins d\'information');

define('MY_NEWSLETTERS_TITLE', 'Mes abonnements aux bulletins d\'informations');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Bulletin d\'informations général');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Concerne les actualités du site, les nouveaux produits, les offres spéciales, et autres annonces promotionnelles.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Vos abonnements au bulletin d\'informations ont été mis à jour.');
?>
