<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_INSTALL_DIRECTORY_EXISTS', 'Le dossier d\'installation existe dans: ' . DIR_FS_CATALOG . 'install. Supprimez ce répertoire pour des raisons de sécurité.');
?>
