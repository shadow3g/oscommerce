<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Conta Pessoal');
define('NAVBAR_TITLE_2', 'Hist�rico');

define('HEADING_TITLE', 'Hist�rico de Encomendas');

define('TEXT_ORDER_NUMBER', 'Encomenda N.�:');
define('TEXT_ORDER_STATUS', 'Estado:');
define('TEXT_ORDER_DATE', 'Data:');
define('TEXT_ORDER_SHIPPED_TO', 'Enviado para:');
define('TEXT_ORDER_BILLED_TO', 'Cobrado a:');
define('TEXT_ORDER_PRODUCTS', 'Artigos:');
define('TEXT_ORDER_COST', 'Total:');
define('TEXT_VIEW_ORDER', 'Visualizar');

define('TEXT_NO_PURCHASES', 'Ainda n�o efectuou nenhuma compra.');
?>
