<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Módulos Contenido');

define('TABLE_HEADING_MODULES', 'Módulos');
define('TABLE_HEADING_GROUP', 'Grupo');
define('TABLE_HEADING_SORT_ORDER', 'Orden de Clasificación');
define('TABLE_HEADING_ACTION', 'Acción');

define('TEXT_INFO_VERSION', 'versión:');
define('TEXT_INFO_ONLINE_STATUS', 'estado en línea');
define('TEXT_INFO_API_VERSION', 'API Versión:');

define('TEXT_MODULE_DIRECTORY', 'Directorio del módulo:');
?>
