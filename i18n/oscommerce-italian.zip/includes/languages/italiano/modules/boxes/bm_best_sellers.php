<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_BEST_SELLERS_TITLE', 'Piu\' venduti');
  define('MODULE_BOXES_BEST_SELLERS_DESCRIPTION', 'Mostra generale e categorie piu\' venduti');
  define('MODULE_BOXES_BEST_SELLERS_BOX_TITLE', 'Piu\' venduti');
?>
