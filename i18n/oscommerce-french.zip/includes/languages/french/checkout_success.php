<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Caisse');
define('NAVBAR_TITLE_2', 'Succès');

//define('HEADING_TITLE', 'Votre commande vient d\'être prise en compte !');
define('HEADING_TITLE', 'Votre commande a été traitée!');

//define('TEXT_SUCCESS', 'Votre commande vient d\'être enregistrée par notre système ! Vos produits arriveront à destination dans 2-5 jours ouvrés');
//define('TEXT_NOTIFY_PRODUCTS', 'Veuillez m\'alerter des mises à jour des produits que j\'ai choisis ci-dessous :');
//define('TEXT_SEE_ORDERS', 'Vous pouvez voir l\'historique de votre commande en consultant la page <a href="' . tep_href_link(FILENAME_ACCOUNT, '', 'SSL') . '">\'Mon compte\'</a> et en cliquant sur <a href="' . tep_href_link(FILENAME_ACCOUNT_HISTORY, '', 'SSL') . '">\'Historique\'</a>.');
//define('TEXT_CONTACT_STORE_OWNER', 'Veuillez poser toute question au <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">gestionnaire du site</a>.');
//define('TEXT_THANKS_FOR_SHOPPING', 'Merci d\'avoir fait vos achats en ligne avec nous !');
//define('TABLE_HEADING_COMMENTS', 'Ecrivez un commentaire pour la commande passée;');
define('TABLE_HEADING_COMMENTS', 'Entrez un commentaire pour la commande traitée');

//define('TABLE_HEADING_DOWNLOAD_DATE', 'date d\'expiration : ');
//define('TABLE_HEADING_DOWNLOAD_COUNT', ' téléchargement(s) restant');
//define('HEADING_DOWNLOAD', 'Téléchargez vos produits ici :');
//define('FOOTER_DOWNLOAD', 'Vous pourrez télécharger vos produits plus tard sur \'%s\'');
?>
