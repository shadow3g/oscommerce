<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SHOPPING_CART_TITLE', 'Carrello');
  define('MODULE_BOXES_SHOPPING_CART_DESCRIPTION', 'Mostra contenuto carrello');
  define('MODULE_BOXES_SHOPPING_CART_BOX_TITLE', 'Carrello');
  define('MODULE_BOXES_SHOPPING_CART_BOX_CART_EMPTY', '0 prodotti');
?>
