<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Effettuare il login');
define('NAVBAR_TITLE_2', 'Reimpostazione password');

define('HEADING_TITLE', 'Reimpostazione password');

define('TEXT_MAIN', 'Immettere una nuova password per il tuo account');

define('TEXT_NO_RESET_LINK_FOUND', 'Errore: Il link per reimpostare la password non è presente nei nostri archivi, si prega di riprovare generando un nuovo link.');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', 'Errore: L\'E-mail non è nei nostri archivi, si prega di riprovare.');

define('SUCCESS_PASSWORD_RESET', 'La tua password è stata aggiornata. Effettua il login con la nuova password.');
?>
