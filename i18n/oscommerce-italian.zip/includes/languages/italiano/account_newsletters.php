<?php
/*
  $Id: account_newsletters.php,v 1.1 2003/05/19 19:55:45 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Il mio Account');
define('NAVBAR_TITLE_2', 'Sottoscrizioni alla Newsletter');

define('HEADING_TITLE', 'Sottoscrizioni alla Newsletter');

define('MY_NEWSLETTERS_TITLE', 'Le mie sottoscrizioni alla Newsletter');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Newsletter Generale');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Include le notizie sul negozio, sui prodotti aggiunti, sulle offerte speciali e le priomizioni in corso.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Le tue sottoscritioni sono state aggiornate con successo.');
?>
