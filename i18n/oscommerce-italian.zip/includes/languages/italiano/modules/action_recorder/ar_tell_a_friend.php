<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_TELL_A_FRIEND_TITLE', 'Segnala ad un amico');
  define('MODULE_ACTION_RECORDER_TELL_A_FRIEND_DESCRIPTION', 'Storico utilizzo modulo Segnala ad un amico.');
?>
