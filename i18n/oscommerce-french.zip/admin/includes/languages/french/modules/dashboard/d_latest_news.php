<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_TITLE', 'Dernières nouveautés');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DESCRIPTION', 'Affiche les dernières nouveautés osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DATE', 'Date');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_FEED_ERROR', 'Impossible de se connecter au flux des nouveautés osCommerce. La prochaines tentative sera effectuée dans 24 heures.');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWSLETTER', 'Abonnez-vous à la Newsletter osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_FACEBOOK', 'Devenir Fan osCommerce sur Facebook');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_TWITTER', 'Suivre osCommerce sur Twitter');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_RSS', 'S\'abonner au flux RSS des News osCommerce');
// added for ver 2.3.4 bof 
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWS', 'Lisez le dernier osCommerce Nouvelles '); 
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_GOOGLE_PLUS', 'Cercle osCommerce sur Google+'); 
// added for ver 2.3.4 eof 

?>
