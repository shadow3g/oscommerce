<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Logo de la boutique');

define('TEXT_LOGO_IMAGE', 'Nouveau Logo:');
define('TEXT_FORMAT_AND_LOCATION', 'Le logo doit être au format PNG et sera sauver en:');

define('SUCCESS_LOGO_UPDATED', 'Réussite: le logo de la boutique a été mis à jour');

define('ERROR_IMAGES_DIRECTORY_NOT_WRITEABLE', 'Erreur: Le répertoire des images est en lecture seule. (<a href="%s">cliquez ici pour revoir les permissions sur le répertoire</a>)');
?>
