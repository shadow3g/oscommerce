<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ORDERS_TITLE', 'Commandes');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DESCRIPTION', 'Affiche les dernières commandes');
define('MODULE_ADMIN_DASHBOARD_ORDERS_TOTAL', 'Total');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DATE', 'Date');
define('MODULE_ADMIN_DASHBOARD_ORDERS_ORDER_STATUS', 'Etat');
?>
