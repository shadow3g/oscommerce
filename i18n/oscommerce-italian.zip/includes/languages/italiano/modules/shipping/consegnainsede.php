<?php
/*
  modulo di spedizione tramite Consegna in Sede
  by hOZONE, hozone@tiscali.it, http://hozone.cjb.net

  visita osCommerceITalia, http://www.oscommerceitalia.com
  
  derivato dal modulo:
  $Id: flat.php,v 1.5 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_CONSEGNAINSEDE_TEXT_TITLE', 'Consegna in Sede');
define('MODULE_SHIPPING_CONSEGNAINSEDE_TEXT_DESCRIPTION', 'Consegna della merce presso la nostra sede.');
define('MODULE_SHIPPING_CONSEGNAINSEDE_TEXT_WAY', 'Consegna della merce presso la nostra sede di <br />&nbsp;&nbsp;&nbsp;&nbsp;'. MODULE_SHIPPING_CONSEGNAINSEDE_ADDR_VIA . '<br />&nbsp;&nbsp;&nbsp;&nbsp;' . MODULE_SHIPPING_CONSEGNAINSEDE_ADDR_CAP . ', ' . MODULE_SHIPPING_CONSEGNAINSEDE_ADDR_CITTA);
?>
