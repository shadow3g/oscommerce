<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_LOWORDERFEE_TITLE', 'Valor mínimo del pedido');
  define('MODULE_ORDER_TOTAL_LOWORDERFEE_DESCRIPTION', 'Valor mínimo del pedido');
?>
