<?php
/*
  $Id: privacy.php,v 1.8 2007/06/28 03:13:39 sd_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2003 osCommerce
  Released under the GNU General Public License
  Norwegian language files MS2.2
  
*/

define('NAVBAR_TITLE', 'Informativa sulla Privacy');
define('HEADING_TITLE', 'Informativa sulla Privacy');

define('TEXT_INFORMATION', 'Inserisci il tuo Informativa sulla Privacy qui!
');

?>
