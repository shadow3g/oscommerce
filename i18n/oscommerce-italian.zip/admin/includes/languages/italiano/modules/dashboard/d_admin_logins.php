<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_TITLE', 'Ultimo Amministratore che ha effettuato il Login');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DESCRIPTION', 'Mostra i tentativi di entrata degli ultimi amministratori del sito che hanno effettuato il login');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DATE', 'Data');
?>
