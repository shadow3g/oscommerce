<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_ORDER_HISTORY_TITLE', 'Histórico de pedidos');
  define('MODULE_BOXES_ORDER_HISTORY_DESCRIPTION', 'Mostrar los productos solicitados previamente por los Clientes');
  define('MODULE_BOXES_ORDER_HISTORY_BOX_TITLE', 'Histórico de pedidos');
?>
