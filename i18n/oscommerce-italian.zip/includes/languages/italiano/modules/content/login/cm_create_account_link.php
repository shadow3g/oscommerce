<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_TITLE', 'Crea un account collegamento');
  define('MODULE_CONTENT_CREATE_ACCOUNT_LINK_DESCRIPTION', 'Mostra un contenitore di creare un account nella pagina di login');

  define('MODULE_CONTENT_LOGIN_HEADING_NEW_CUSTOMER', 'Nuovo Cliente ');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER', 'Sono un nuovo cliente.');
  define('MODULE_CONTENT_LOGIN_TEXT_NEW_CUSTOMER_INTRODUCTION', 'Creando un nuovo account da ' . STORE_NAME . ' sarai in grado di acquistare velocemente, essere sempre aggiornato sullo stato dei tuoi ordini e tenere traccia degli ordini che hai effettuato.');
?>
