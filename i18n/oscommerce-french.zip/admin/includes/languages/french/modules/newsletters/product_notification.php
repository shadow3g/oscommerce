<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Clients recevant le Bulletin d\'information: %s');
define('TEXT_PRODUCTS', 'Produits');
define('TEXT_SELECTED_PRODUCTS', 'Produits sélectionnés');

define('JS_PLEASE_SELECT_PRODUCTS', 'Veuillez sélectionner au moins 1 produit.');

define('BUTTON_GLOBAL', 'Globale');
define('BUTTON_SELECT', '>>>');
define('BUTTON_UNSELECT', '<<<');
define('BUTTON_SUBMIT', 'Envoyer');
define('BUTTON_CANCEL', 'Annuler');
?>