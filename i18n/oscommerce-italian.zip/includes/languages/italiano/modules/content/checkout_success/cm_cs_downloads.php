<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_TITLE', 'Download di prodotti');
  define('MODULE_CONTENT_CHECKOUT_SUCCESS_DOWNLOADS_DESCRIPTION', 'Mostra ordinato prodotti link per il download nella pagina successo checkout');

  define('TABLE_HEADING_DOWNLOAD_DATE', 'Data di scadenza:');
  define('TABLE_HEADING_DOWNLOAD_COUNT', ' download rimanenti');
  define('HEADING_DOWNLOAD', 'Scarica i vostri prodotti qui:');
  define('FOOTER_DOWNLOAD', 'È anche possibile scaricare i vostri prodotti in un secondo momento a \'%s\'');
?>
