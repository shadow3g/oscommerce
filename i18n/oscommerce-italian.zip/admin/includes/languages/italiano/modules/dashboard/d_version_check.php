<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_TITLE', 'Verifica Versione');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DESCRIPTION', 'Mostra i risultati sulla verifica della versione');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DATE', 'Ultima Checked On');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_CHECK_NOW', 'Check Now');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_NEVER', 'Mai');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_UPDATE_AVAILABLE', 'E\' disponibile un aggiornamento di osCommerce Online Merchant!');
?>
