<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_TITLE', 'admin/backups/ File di accesso');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_HTTP_200', 'I file di backup in ' . DIR_WS_ADMIN . 'backups/ possono essere consultati e scaricati direttamente - si prega di disabilitare l\'accesso pubblico a questa cartella nella configurazione del server web.');
?>
