<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SHOPPING_CART_TITLE', 'Cesta de Compras');
  define('MODULE_BOXES_SHOPPING_CART_DESCRIPTION', 'Mostrar el contenido de la Cesta de Compras');
  define('MODULE_BOXES_SHOPPING_CART_BOX_TITLE', 'Cesta de Compras');
  define('MODULE_BOXES_SHOPPING_CART_BOX_CART_EMPTY', '0 artículos');
?>
