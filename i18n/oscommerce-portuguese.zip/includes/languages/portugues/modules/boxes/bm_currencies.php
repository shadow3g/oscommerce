<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CURRENCIES_TITLE', 'Divisas');
  define('MODULE_BOXES_CURRENCIES_DESCRIPTION', 'Mostrar divisas  disponíveis');
  define('MODULE_BOXES_CURRENCIES_BOX_TITLE', 'Divisas');
?>