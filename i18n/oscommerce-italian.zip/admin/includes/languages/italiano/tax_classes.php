<?php 
/*
  $Id$
 
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
 
  Copyright (c) 2002 osCommerce
 
  Released under the GNU General Public License


*/

define('HEADING_TITLE', 'Tipo di Tasse');

define('TABLE_HEADING_TAX_CLASSES', 'Tipo di Tasse');
define('TABLE_HEADING_ACTION', 'Azione');

define('TEXT_INFO_EDIT_INTRO', 'Effettua i cambiamenti necessari');
define('TEXT_INFO_CLASS_TITLE', 'Titolo Tipo di Tassa:');
define('TEXT_INFO_CLASS_DESCRIPTION', 'Descrizione:');
define('TEXT_INFO_DATE_ADDED', 'Data inserimento:');
define('TEXT_INFO_LAST_MODIFIED', 'Ultima modifica:');
define('TEXT_INFO_INSERT_INTRO', 'Inserisci il nuovo tipo di Tassa con i rispettivi dati ');
define('TEXT_INFO_DELETE_INTRO', 'Sicuro di voler cancellare questo tipo di Tassa?');
define('TEXT_INFO_HEADING_NEW_TAX_CLASS', 'Nuova tipo di Tassa');
define('TEXT_INFO_HEADING_EDIT_TAX_CLASS', 'Nuova tipo di Tassa');
define('TEXT_INFO_HEADING_DELETE_TAX_CLASS', 'Cancella tipo di Tassa');
?>
