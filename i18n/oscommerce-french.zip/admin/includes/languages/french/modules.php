<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_MODULES', 'Modules');
define('TABLE_HEADING_SORT_ORDER', 'Ordre d\'affichage');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_VERSION', 'Version:');
define('TEXT_INFO_ONLINE_STATUS', 'Etat d\'activation');
define('TEXT_INFO_API_VERSION', 'Version de l\'API:');

define('TEXT_MODULE_DIRECTORY', 'Répertoire du module:');
?>
