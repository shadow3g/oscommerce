<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_TITLE', 'Titolo Prodotto');
  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_DESCRIPTION', 'Aggiungi il titolo dell\'attuale prodotto al titolo della pagina');
?>
