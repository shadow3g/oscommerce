<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_TITLE', 'Notifica��es de Artigos');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_DESCRIPTION', 'Mostrar Notifica��es de Artigos');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_TITLE', 'Notifica��es');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY', 'Notificar actualiza��es a <strong>%s</strong>');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY_REMOVE', 'N�o notificar actualiza��es a <strong>%s</strong>');
?>
