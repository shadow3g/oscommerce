<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_LOGIN_FORM_TITLE', 'Connectez-Forme');
  define('MODULE_CONTENT_LOGIN_FORM_DESCRIPTION', 'Afficher un formulaire de connexion sur la page de connexion');

  define('MODULE_CONTENT_LOGIN_HEADING_RETURNING_CUSTOMER', 'Je suis déjà client');
  define('MODULE_CONTENT_LOGIN_TEXT_RETURNING_CUSTOMER', 'Je suis un client de retour.');
  define('MODULE_CONTENT_LOGIN_TEXT_PASSWORD_FORGOTTEN', 'Mot de passe oublié? Cliquez ici.');

  define('MODULE_CONTENT_LOGIN_TEXT_LOGIN_ERROR', 'Erreur: Aucun résultat pour adresse et/ou mot de passe E-Mail.');
?>
