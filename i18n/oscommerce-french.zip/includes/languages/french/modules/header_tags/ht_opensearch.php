<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_OPENSEARCH_TITLE', 'Technologie OpenSearch');
  define('MODULE_HEADER_TAGS_OPENSEARCH_DESCRIPTION', 'Autorise le navigateur à ajouter votre boutique dans ses moteurs de recherche via la technologie OpenSearch.');
?>
